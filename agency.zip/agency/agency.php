<?php
/*
* Plugin Name:افزونه نمایندگان
* Plugin uri:http://www.rozalweb.ir
* Description:با افزونه فارسی نمایندگان ,می توانید اطلاعات نمایندگان و همکاران خود را ثبت کرده و مشخصات آنها را به کاربران نمایش دهید
* Version:2.6
* Author:seyedreza
* Author uri:http://ibulut.ir
*/
register_activation_hook(__FILE__,array('agency','install'));
define('AGENCY_PLUGIN', plugin_dir_path(__FILE__));
require_once AGENCY_PLUGIN. 'plugin.php';

?>