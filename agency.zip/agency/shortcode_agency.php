<?php
if ( ! defined('ABSPATH')) exit('restricted access');
global $wpdb;
// This will enqueue the Media Uploader script
 if(isset($_GET['action']) && isset($_GET['id']) && isset($_GET['action'])=="edit"){
 $table_name=$wpdb->prefix."img_events_list";
 $id=$_GET["id"];
 $img_events=$wpdb->get_row('SELECT * FROM '.$table_name.' WHERE id='.$id,ARRAY_A);

 }//end if edit
 wp_enqueue_media();
?>
<div class="agency_box">
  <div class="agency_titr">
   <span>شورتکد افزونه نمایندگان</span>
   <div class="agency_fil_left">
     <a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=agency" id="list_agency">لیست نمایندگان</a>
  </div>
</div>
<div class="agency_context">
<h2>برای ساخت شورتکد و استفاده در وبسایت:</h2>
<p>  ابتدا نوع نمایندگی های  مورد نظر برای نمایش را انتخاب و سپس بر روی دکمه ساخت شورتکد کلیک کنید</p>
</div>

    <h3 id="agency_chosecat">انتخاب نوع نمایندگی</h3>
    <select id="agency_shocat">
    <option value="all">همه نمایندگی ها</option>
    <option value="wish">نوع نمایندگی دلخواه</option>
    </select>
     <div class="agency_cat_checkbox">
       <ul>
        <?php
         $agency_type=$wpdb->get_results('SELECT * FROM '.$wpdb->prefix."agency_type".' ORDER BY id ASC',ARRAY_A);
         foreach($agency_type as $agency_type)
         {
       ?>
       <li><input type="checkbox" name="agency_type_checkbox[]" class="agency_type_checkbox"  value="<?php echo $agency_type['id']; ?>"/><?php echo $agency_type['name']; ?></li>
         <?php
         }//end foreach

        ?>

        </ul>
        </div>

        <a href="javascript:void(0)" class="agency_btn agency_btn-success" id="agency_createcode">ایجاد شورتکد</a>
          <div id="agency_coderes"></div>
  </div>
