jQuery(function() {

    jQuery(window).resize(function() {
        resposive_agency();
    });

      function resposive_agency()
       {
          var height = jQuery('#map_agency .agency_list').height();
          var width = jQuery('#map_agency .agency_list').width();
          if (height > width)
           {
            jQuery('.map_agency').height(width-1).width(width-10);
            //jQuery('.map_agency svg').height(width-1).width(width-10);
           }
           else {
            jQuery('.map_agency').height(height-1).width(height-10);
            //jQuery('.map_agency svg').height(height-1).width(height-10);
           }

           // var width_shahr=jQuery('#agency_shahr').width();
            //if(width_shahr>500){
            // jQuery('.city_link').css({'width': '200px'});
            //}

       }//end resposive_agency()
       jQuery(window).on( "load", function() {
       resposive_agency();
       });
    var myostan=new Array();
        myostan[0]="خخ";
        myostan[1]="آذربایجان شرقی";
        myostan[2]="آذربایجان غربی";
        myostan[3]="اردبیل";
        myostan[4]="اصفهان";
        myostan[5]="البرز";
        myostan[6]="ایلام";
        myostan[7]="بوشهر";
        myostan[8]="تهران";
        myostan[9]="چهارمحال بختیاری";
        myostan[10]="خراسان جنوبی";
        myostan[11]="خراسان رضوی";
        myostan[12]="خراسان شمالی";
        myostan[13]="خوزستان";
        myostan[14]="زنجان";
        myostan[15]="سمنان";
        myostan[16]="سیستان و بلوچستان";
        myostan[17]="فارس";
        myostan[18]="قزوین";
        myostan[19]="قم";
        myostan[20]="کردستان";
        myostan[21]="کرمان";
        myostan[22]="کرمانشاه";
        myostan[23]="کهگیلویه و بویراحمد";
        myostan[24]="گلستان";
        myostan[25]="گیلان";
        myostan[26]="لرستان";
        myostan[27]="مازندران";
        myostan[28]="مرکزی";
        myostan[29]="هرمزگان";
        myostan[30]="همدان";
        myostan[31]="یزد";
        myostan[32]="ابوموسی";
        myostan[33]="قشم";
        myostan[34]="فرور بزرگ";
        myostan[35]="فرور کوچک";
        myostan[36]="هندورابی";
        myostan[37]="هنگام";
        myostan[38]="هرمز";
        myostan[39]="خارک";
        myostan[40]="کیش";
        myostan[41]="لارک";
        myostan[42]="لاوان";
        myostan[43]="سیری";
        myostan[44]="تنب بزرگ";
        myostan[45]="تنب کوچک";


          jQuery('a[rel=ajax]').click(function()
    {
      var action="city_agency";
      var type=jQuery('input#agency_type_list').val();
      var num=jQuery(this).attr('id');
      //jQuery('.agency_list a[rel=ajax]').css('display','none');
      //jQuery(this).css('display','block');
      jQuery.ajax(
     {
      url:myAjax.ajaxurl,
      type:"POST",
      data:{id:num,type:type,action:"city_agency"},
      beforeSend: function() {
          //jQuery(".agency_list_ostan").hide();
           jQuery("#agency_joz").html("");
           jQuery("#agency_shahr").html("");
           jQuery("#agency_show").html("");
            jQuery(".agency_city_title").html("").css({'display': 'none'});
            //jQuery("#ag_list_shahr").css('display','none').html("");
          jQuery("#agency_load").html('<div class="agency_loading"> </div>');
     },
      success:function(data)
     {
      jQuery("#agency_load").html('');
      var w =jQuery(window).width();
       if(w >768)
       {
       var height_top=jQuery("#map_agency").offset().top;
       //var height = jQuery('#map_agency .agency_list').height();
       var height2=height_top+60;
      jQuery('html, body').animate({
        scrollTop:height2
      }, 2000);
  // jQuery("html, body").scrollTop();

       }//w end
       else if(w < 768){
       var height_top=jQuery("#map_agency").offset().top;
       var height = jQuery('#map_agency .agency_list').height();
       var height1= jQuery('#map_agency .map_agency').height();
       var height2=height1+height+height_top-200;
      jQuery('html, body').animate({
        scrollTop:height2
      }, 2000);

       }
      jQuery(".agency_ostan_titr").slideDown("slow").html(myostan[num]);
      //jQuery("#ag_list_shahr").css('display','block').html('<span class="agency_blink">لطفا شهر مورد نظر را انتخاب کنید</span>').fadeIn();
      jQuery("#agency_res_city").slideDown("slow").html(data);
     }
     });//end ajax

     }); //end ajax click

   agency_more=function(id) {

    jQuery("#agencymore-"+id).toggle(500,red());
    function red(){
     var dis=jQuery("#agencymore-"+id).css("display");
     if(dis=="none") {
      jQuery("#agencymob-"+id).text("-");
      jQuery("#agencymod-"+id).text("اطلاعات کم تر");
      }
      else{
       jQuery("#agencymob-"+id).text("+");
       jQuery("#agencymod-"+id).text("اطلاعات بیشتر");

      }
    }


   }

     jQuery('#map_agency svg g path').hover(function() {
            var className = jQuery(this).attr('class');
            var parrentClassName = jQuery('#map_agency svg g a').parent('g').attr('class');
            var itemName = jQuery('#map_agency .agency_list .' + parrentClassName + ' .' + className + ' a').html();
             if (itemName)
              {
                jQuery('#map_agency .agency_list .' + parrentClassName + ' .' + className + ' a').addClass('hover');
                jQuery('#map_agency .show-title').html(itemName).css({'display': 'block'});
              }
    }, function() {
        jQuery('#map_agency .agency_list a').removeClass('hover');
        jQuery('#map_agency .show-title').html('').css({'display': 'none'});
    });//end map hover

     jQuery('#map_agency .agency_list ul li ul li a').hover(function() {
            var className =  jQuery(this).parent('li').attr('class');
            var parrentClassName =  jQuery(this).parent('li').parent('ul').parent('li').attr('class');
            var object = '#map_agency svg g.' + parrentClassName + ' path.' + className;
            var currentClass =  jQuery(object).attr('class');
            jQuery(object).attr('class', currentClass + ' hover');
            var itemName= jQuery(this).text();
            jQuery('.agency_list .list-title').html(itemName).css({'display': 'block'});
    }, function() {
           var className =  jQuery(this).parent('li').attr('class');
           var parrentClassName =  jQuery(this).parent('li').parent('ul').parent('li').attr('class');
           var object = '#map_agency svg g.' + parrentClassName + ' path.' + className;
          var currentClass =  jQuery(object).attr('class');
          jQuery('.agency_list .list-title').html('').css({'display': 'none'});
          jQuery(object).attr('class', currentClass.replace(' hover', ''));
    });//end map list

     jQuery('#map_agency').mousemove(function(e) {
        var posx = 0;
        var posy = 0;
        if (!e)
            var e = window.event;
        if (e.pageX || e.pageY) {
            posx = e.pageX;
            posy = e.pageY;
        } else if (e.clientX || e.clientY) {
            posx = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
            posy = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
        }
        if ( jQuery('#map_agency .show-title').html()) {
            var offset =  jQuery(this).offset();
            var x = (posx - offset.left + 25) + 'px';
            var y = (posy - offset.top - 5) + 'px';
             jQuery('#map_agency .show-title').css({'left': x, 'top': y});
        }
    });//end map  mousemove
    jQuery('.agency_list a').mousemove(function(e) {
        var posx = 0;
        var posy = 0;
        if (!e)
            var e = window.event;
        if (e.pageX || e.pageY) {
            posx = e.pageX;
            posy = e.pageY;
        } else if (e.clientX || e.clientY) {
            posx = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
            posy = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
        }
        if ( jQuery('.agency_list .list-title').html()) {
            var offset =  jQuery(this).offset();
            var x = (posx - offset.left + 25) + 'px';
            var y = (posy - offset.top - 5) + 'px';
             jQuery('.agency_list .list-title').css({'left': x, 'top': y});
        }
    });//end list mousemove

   jQuery("#show_agency_ostan").click(function(){

   //jQuery(".agency_list_ostan").slideDown("slow");
   jQuery('a[rel=ajax]').css('display','block');

   });

    jQuery('.agency_search_box').keypress(function(e){
    if (e.which === 13) {
      event.preventDefault();
      agency_search_box();

    }//e.which

  });
  var agency_search_box=function()
  {
   var type_search=jQuery("#agency_type_search").val();
   var search_text=jQuery("#agency_search_text").val();
   var type=jQuery('input#agency_type_list').val();
     if(type_search!="none" &&  search_text!=""){
       jQuery.ajax(
       {
        url:myAjax.ajaxurl,
        type:"POST",
        data:{type_search:type_search,search_text:search_text,type:type,action:"search_agency"},
        beforeSend: function(){
          jQuery("#agency_show").html("");
          jQuery("#agency_joz").fadeOut('slow').html("");
          jQuery(".agency_ostan_titr").html("").css({'display': 'none'});
          jQuery("#agency_shahr").html("").css({'display': 'none'});
          jQuery("#agency_load").html('<div class="agency_loading"> </div>');
          jQuery("#ag_list_shahr").css('display','none').html("");
         },
        success:function(data)
         {
           var w =jQuery(window).width();
          jQuery("#agency_load").html('');
          if(w >768)
       {
       var height_top=jQuery("#map_agency").offset().top;
       //var height = jQuery('#map_agency .agency_list').height();
       var height2=height_top+60;
      jQuery('html, body').animate({
        scrollTop:height2
      }, 2000);
  // jQuery("html, body").scrollTop();

       }//w end
       else if(w < 768){
       var height_top=jQuery("#map_agency").offset().top;
       var height = jQuery('#map_agency .agency_list').height();
       var height1= jQuery('#map_agency .map_agency').height();
       var height2=height1+height+height_top-200;
      jQuery('html, body').animate({
        scrollTop:height2
      }, 2000);

       }
           jQuery(".agency_city_title").slideDown().html('<h3><span class="ag_city agency_blink">نتایج جست و جو برای  <span class="agency_search_light">'+search_text+'</span></span></h3>');
          jQuery("#agency_joz").slideDown("slow").html(data);
         }
        });//end ajax
   }
   else if(type_search=="none" &&  search_text=="")
   {
    alert("لطفا فیلدهای جست وجو را تکمیل کنید");
   }
   else if(type_search=="none" && search_text!="")
   {
    alert("لطفا نوع جست وجو را مشخص کنید");
   }
   else if(type_search!="none" && search_text=="")
   {
    alert("لطفا نام شهر یا نام نمایندگی  برای جست و جو وارد نمایید");
   }

  }//agency_search_box function


   jQuery("#search_agency").click(function(){
    agency_search_box();
   });


    });//end jquery
    function list_agency(name,ostan)
      {
       var action="list_agency";
       var num=name;
       var ostani=ostan;
       var type=jQuery('input#agency_type_list').val();
       jQuery.ajax(
       {
        url:myAjax.ajaxurl,
        type:"POST",
        data:{id:num,ostani:ostan,type:type,action:"list_agency"},
        beforeSend: function(){
          jQuery("#agency_show").html("");
          jQuery("#agency_joz").fadeOut('slow').html("");
          jQuery("#agency_load").html('<div class="agency_loading"> </div>');
          jQuery("#ag_list_shahr").css('display','none').html("");
         },
        success:function(data)
         {
          jQuery("#agency_load").html('');
           var w =jQuery(window).width();
          if(w >768)
         {
          var height_top=jQuery("#map_agency").offset().top;
          var height2=height_top+180;
          jQuery('html, body').animate({
          scrollTop:height2
         }, 2000);

       }//w end
       else if(w < 768){
       var height_top=jQuery("#map_agency").offset().top;
       var height = jQuery('#map_agency .agency_list').height();
       var height1= jQuery('#map_agency .map_agency').height();
       var height2=height1+height+height_top-100;
      jQuery('html, body').animate({
        scrollTop:height2
      }, 2000);

       }
          //jQuery("html, body").animate({scrollTop:jQuery(document).height()-jQuery(window).height() },'slow');
           jQuery(".agency_city_title").slideDown().html('<h3><span class="ag_city agency_blink">'+num+'</span></h3>');
          jQuery("#agency_joz").slideDown("slow").html(data);
         }
        });//end ajax
       }//end list_agency

       function self_agency(blue)
       {
        var action="self_agency";
        var num=blue;
        jQuery.ajax(
        {
         url:myAjax.ajaxurl,
         type:"POST",
         data:{id:num,action:"self_agency"},
         beforeSend: function() {
         jQuery("#agency_show").html("");
         jQuery("#agency_load").html('<div class="agency_wait"> </div>');
     	},
        success:function(data)
        {
         jQuery("#agency_load").html('');
         jQuery("#agency_show").html(data);

        }
        });//end ajax
       }//end self_agency()
