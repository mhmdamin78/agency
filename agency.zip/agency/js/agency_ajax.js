jQuery(document).ready(function($){
    // jQuery=jQuery.noConflict();

   jQuery("#checkAll").change(function()
     {
       jQuery("input:checkbox").prop('checked', jQuery(this).prop("checked"));
    });//end jquery check all

    jQuery('.del_agency').click(function()
    {
      var allVals = [];
      jQuery("input[name='check_list[]']:checked").each(function()
      {
      allVals.push( jQuery(this).val());

      });//end input

      if(allVals.length>0)
       {
        var x=confirm("آیا از حذف نمایندگی مطمئن هستید؟") ;
          if (x==true)
          {
           jQuery.ajax(
                {
                 url:myAjax.ajaxurl,
                 type:"POST",
                 data:{id:allVals,action:"del_agency"},
                 success:function(data)
                 {
                 jQuery("#agency_res").addClass("updated");
                  jQuery("#agency_res").html(data);
                  jQuery.each( allVals, function( key, value ) {
                  jQuery("tr#"+value).fadeOut('slow');
                  });
                 }
                });//end ajax
          } //end if x
          else
          {

          }

      }//end if

    });//end del_agency click

    jQuery('#a_state').on('change', function (e) {
    //var state= jQuery("option:selected", this);
       var state= this.value;
       jQuery.ajax(
       {
        url:myAjax.ajaxurl,
        type:"POST",
        data:{id:state,action:"city"},
        beforeSend: function() {
        jQuery("#result").html('<div class="agency_wait"> </div>');
       },
        success:function(data)
        {
         jQuery("#result").html('');
         jQuery("#agency_lcity").html(data);
        }
       });

       });//jQuery a_state

      jQuery('.ditail_agency').click(function()
       {
        var action="ditail_agency";
        var num=jQuery(this).attr('id');
       jQuery.ajax(
       {
        url:myAjax.ajaxurl,
        type:"POST",
        data:{id:num,action:"ditail_agency"},
        beforeSend: function() {
		jQuery("#agency_joz").html("");
        jQuery("#agency_load").html('<div class="agency_loading"> </div>');
       },
       success:function(data)
       {
        jQuery("#agency_load").html('');
        jQuery("#agency_joz").slideDown("slow").html(data).css("background-color", "#eee");
       }
       });//end ajax
     });//end


         jQuery('.del_agency_brands').click(function()
    {
      var allVals = [];
      jQuery("input[name='check_list[]']:checked").each(function()
      {
      allVals.push( jQuery(this).val());

      });//end input

      if(allVals.length>0)
       {
        var x=confirm("آیا از حذف برند مطمئن هستید؟") ;
          if (x==true)
          {
           jQuery.ajax(
                {
                 url:myAjax.ajaxurl,
                 type:"POST",
                 data:{id:allVals,action:"del_agency_brands"},
                 success:function(data)
                 {
                 jQuery("#agency_res").addClass("updated");
                  jQuery("#agency_res").html(data);
                  jQuery.each( allVals, function( key, value ) {
                  jQuery("tr#"+value).fadeOut('slow');
                  });
                 }
                });//end ajax
          } //end if x
          else
          {

          }

      }//end if

    });//end del_agency click

    jQuery('.del_agency_type').click(function()
    {
      var allVals = [];
      jQuery("input[name='check_list[]']:checked").each(function()
      {
      allVals.push( jQuery(this).val());

      });//end input

      if(allVals.length>0)
       {
        var x=confirm("آیا از حذف نوع نمایندگی مطمئن هستید؟") ;
          if (x==true)
          {
           jQuery.ajax(
                {
                 url:myAjax.ajaxurl,
                 type:"POST",
                 data:{id:allVals,action:"del_agency_type"},
                 success:function(data)
                 {
                 jQuery("#agency_res").addClass("updated");
                  jQuery("#agency_res").html(data);
                  jQuery.each( allVals, function( key, value ) {
                  jQuery("tr#"+value).fadeOut('slow');
                  });
                 }
                });//end ajax
          } //end if x
          else
          {

          }

      }//end if

    });//end del_agency type


   	jQuery('ul.agency_tabs li').click(function(){
		var tab_id = jQuery(this).attr('data-tab');

		jQuery('ul.agency_tabs li').removeClass('current');
	   jQuery('.ag_tab_content').removeClass('current');

		jQuery(this).addClass('current');
	   jQuery("#"+tab_id).addClass('current');
	});


      jQuery('a[class*="edit_brand_"]').click(function()
    {
   var num=jQuery(this).attr('id');
   jQuery(".save_brand_"+num).css("display","block");
   jQuery(".ens_brand_"+num).css("display","block");
   jQuery("#brand_name_"+num).prop('disabled',false);
   jQuery("#brand_name_"+num).css("border-color","#2196F3");
   jQuery(this).css("display","none");
   jQuery("#agency_res").html("");


    });//end edit_cat_ func
       jQuery('a[class*="ens_brand_"]').click(function()
    {
   var num=jQuery(this).attr('id');
   jQuery(".save_brand_"+num).css("display","none");
   jQuery(".ens_brand_"+num).css("display","none");
   jQuery("#brand_name_"+num).prop('disabled',true);
   jQuery("#brand_name_"+num).css("border-color","#ddd");
   jQuery(".ens_brand_"+num).css("display","none");
   jQuery(".edit_brand_"+num).css("display","block");
   jQuery("#agency_res").html("");


    });//end ens_cat_ ens_cat_

    jQuery('a[class*="save_brand_"]').click(function(){

    var brand_id=jQuery(this).attr('id');
    var brand_name=jQuery("#brand_name_"+brand_id).val();
       jQuery.ajax(
       {
       url:myAjax.ajaxurl,
       type:"POST",
       data:{brand_id:brand_id,brand_name:brand_name,action:"edit_brands_agency"},
       beforeSend: function() {
       jQuery("#agency_res").html("");
       },
       success:function(data)
       {

      jQuery("#agency_res").html(data);
      jQuery(".ens_brand_"+brand_id).css("display","none");
      jQuery(".save_brand_"+brand_id).css("display","none");
      jQuery("#brand_name_"+brand_id).prop('disabled',true);
      jQuery("#brand_name_"+brand_id).css("border-color","#ddd");
      jQuery(".edit_brand_"+brand_id).css("display","block");
       }
       });//end

      });//end save_cat_ func



      jQuery('a[class*="edit_type_"]').click(function()
    {
   var num=jQuery(this).attr('id');
   jQuery(".save_type_"+num).css("display","block");
   jQuery(".ens_type_"+num).css("display","block");
   jQuery("#type_name_"+num).prop('disabled',false);
   jQuery("#type_name_"+num).css("border-color","#2196F3");
   jQuery(this).css("display","none");
   jQuery("#agency_res").html("");


    });//end edit_cat_ func
    jQuery('a[class*="ens_type_"]').click(function()
    {
   var num=jQuery(this).attr('id');
   jQuery(".save_type_"+num).css("display","none");
   jQuery(".ens_type_"+num).css("display","none");
   jQuery("#type_name_"+num).prop('disabled',true);
   jQuery("#type_name_"+num).css("border-color","#ddd");
   jQuery(".ens_type_"+num).css("display","none");
   jQuery(".edit_type_"+num).css("display","block");
   jQuery("#agency_res").html("");


    });//end ens_cat_ ens_cat_

    jQuery('a[class*="save_type_"]').click(function(){

    var type_id=jQuery(this).attr('id');
    var type_name=jQuery("#type_name_"+type_id).val();
       jQuery.ajax(
       {
       url:myAjax.ajaxurl,
       type:"POST",
       data:{type_id:type_id,type_name:type_name,action:"edit_type_agency"},
       beforeSend: function() {
       jQuery("#agency_res").html("");
       },
       success:function(data)
       {

      jQuery("#agency_res").html(data);
      jQuery(".ens_type_"+type_id).css("display","none");
      jQuery(".save_type_"+type_id).css("display","none");
      jQuery("#brand_type_"+type_id).prop('disabled',true);
      jQuery("#brand_type_"+type_id).css("border-color","#ddd");
      jQuery(".edit_type_"+type_id).css("display","block");
       }
       });//end

      });//end save_type_ func



      jQuery("#upgrade_agency").click(function(){
       var x=confirm("آیا از ارتقاء نسخه مطمئن هستید؟") ;
          if (x==true)
          {
           jQuery.ajax(
           {
           url:myAjax.ajaxurl,
           type:"POST",
           data:{action:"upgrade_agency"},
           beforeSend:function(){
           jQuery("#upgrade_res").html("");
           jQuery("#agency_load").html('<div class="agency_loading"> </div>');
           },
           success:function(data){
           jQuery("#agency_load").html('');
           if(data==1)
           {
           jQuery("#upgrade_agency").css("display","none");
             jQuery(".upgrade_res").html('<span class="agency_blink">ارتقاء نسخه افزونه با موفقیت انجام شد</span>');
           }
           else
           {
           jQuery(".upgrade_res").html("مشکلی در ارتقاء افزونه به وجود آمد لطفا دوباره تلاش کنید");
           }
           }
           });

           }//end if x

      });

       jQuery('#agency_shocat').on('change', function (e) {
    //var state= jQuery("option:selected", this);
       var type= this.value;
       if(type=="all")
       {
       jQuery('.agency_cat_checkbox').css("display","none");
       }
       else if(type=="wish")
       {
        jQuery('.agency_cat_checkbox').css("display","block");
       }

      });
      jQuery("#agency_createcode").click(function($){
       var type_cat=jQuery("#agency_shocat").val();
       if(type_cat=="all")
       {
        jQuery("#agency_coderes").html('[wp_agency_link type="all"]');
       }
       else if(type_cat=="wish")
       {

       var allVals=[];
      jQuery("input[name='agency_type_checkbox[]']:checked").each(function()
      {
      allVals.push(jQuery(this).val());

      });//end input
      }

      if(allVals.length>0)
       {
       var list_cat=allVals.join();
      jQuery("#agency_coderes").html('[wp_agency_link type="'+list_cat+'"]');

       }
       else
       {
       jQuery("#agency_coderes").html('[wp_agency_link type="all"]');
       }



      });


});//end jquery