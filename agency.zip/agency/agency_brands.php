<?php
if ( ! defined('ABSPATH')) exit('restricted access');
global $wpdb;
$table_name=$wpdb->prefix."agency_brands";
  if(isset($_POST['submit_brand']) && !(isset($_GET['action'])))
   {
      if(!empty($_POST['brand_name']))
     {
      $result=$wpdb->insert($table_name,array('name'=>$_POST['brand_name']),array('%s'));
      if($result)
       {
        echo '<div id="message" class="updated"><p style="color:red">حوزه فعالیت با موفقیت اضافه شد</p></div>';
       }//end result
       else
       {
        echo '<div class="error"><p style="color:red">مشکلی در ثبت  حوزه فعالیت به وجود آمد لطفا دوباره تلاش کنید</p></div>';
       }// else result
     }//end if brand_name
    else
     {
      echo '<div class="error"><p style="color:red">لطفا عنوانی برای حوزه فعالیت انتخاب کنید</p></div>';
     }//end else brand_name
   }// end action add
?>
<div id="agency_res"></div>
<div class="agency_box">
<div class="agency_title">لیست حوزه های فعالیت</div>
<div>
<div class="agency-brands-right">
  <form name="brand" method="post" id="#agency_brands">
    <table>
    <tr>
    <td><input type="text" name="brand_name"  placeholder="افزودن حوزه فعالیت" id="brand_name" value="<?php echo $brands['name'];?>" /><span class="agency_nec"></span></td>
    <td> <input  type="submit"  class="btn_agency  ag-success" name="submit_brand" value="ذخیره" /></td>
    </tr>
   </table>
 </form>
</div>
<div class="agency-brands-left">
<?php

  $pagenum = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
  $limit = get_option("agency_count"); // number of rows in page
  $offset =($pagenum-1) * $limit;
?>
  <div id="agency_fil">
  <div class="agency_fil_right">
     <form  method="get" action="">
      <input type="hidden"  name="page" value="agency_brands" />
      <input type="text" name="s" id="aserach"  value="" placeholder="جست و جو"/>
      <input type="submit" name="submit_state" value="صافی" />
     </form>
  </div>
  <div class="agency_fil_left">
    <a href="#" id="del_" class="del_agency_brands">حذف حوزه فعالیت</a>
  </div>
  </div>
     <table id="tbl_list_agency">
       <tr>
       <th><input type="checkbox" id="checkAll"/></th>
       <th>عنوان حوزه فعالیت</th>
       <th>عملیات</th>
       </tr>
       <?php
       if(isset($_GET['s']) && $_GET['s']!="")
     {
       $i=0;
       $s=$_GET['s'];
       $agency_brands=$wpdb->get_results("SELECT * FROM $table_name WHERE name LIKE '%$s%'  LIMIT  $offset, $limit",ARRAY_A);
       $total= $wpdb->get_var( "SELECT COUNT(`id`) FROM $table_name WHERE name LIKE '%$s%';");



         foreach($agency_brands as $agency_brands)
          {
       $i++;
         ?>
           <tr id="<?php echo $agency_brands['id']; ?>">
           <td class="center"><input type="checkbox" name="check_list[]" value="<?php echo $agency_brands['id']; ?>" /></td>
           <td>
           <input type="text" id="brand_name_<?php echo $agency_brands['id']; ?>" value="<?php echo $agency_brands['name'];?>" disabled="disabled" class="cat_name_db" />
           </td>
           <td>
           <span class="brand_list">
           <a class="edit_brand_<?php echo $agency_brands['id']; ?>" href="javascript:void(0)" id="<?php echo $agency_brands['id']; ?>"> <span id="edit-activator" class="button">ویرایش</span>    </a>
          <a class="save_brand_<?php echo $agency_brands['id']; ?>" style="display:none" href="javascript:void(0)" id="<?php echo $agency_brands['id']; ?>"> <span id="edit-activator" class="button">ذخیره</span> </a>
           <a class="ens_brand_<?php echo $agency_brands['id']; ?>" href="javascript:void(0)" style="display:none"  id="<?php echo $agency_brands['id']; ?>"> <span id="edit-activator" class="button">انصراف</span>    </a>
           </span>
          </td>
           </tr>
           <?php
          }//end foreach img_events
          }//end if sGET
          else
          {
         $i=0;
         $agency_brands=$wpdb->get_results("SELECT * FROM $table_name LIMIT  $offset, $limit",ARRAY_A);
         $total = $wpdb->get_var( "SELECT COUNT(`id`) FROM $table_name");
         foreach($agency_brands as $agency_brands)
          {
           $i++;
         ?>
           <tr id="<?php echo $agency_brands['id']; ?>">
           <td class="center"><input type="checkbox" name="check_list[]" value="<?php echo $agency_brands['id']; ?>" /></td>
           <td>
           <input type="text" id="brand_name_<?php echo $agency_brands['id']; ?>" value="<?php echo $agency_brands['name'];?>" disabled="disabled" class="cat_name_db" />
           </td>
           <td>
           <span class="brands_list">
           <a class="edit_brand_<?php echo $agency_brands['id']; ?>" href="javascript:void(0)" id="<?php echo $agency_brands['id']; ?>"> <span id="edit-activator" class="button">ویرایش</span>    </a>
          <a class="save_brand_<?php echo $agency_brands['id']; ?>" style="display:none" href="javascript:void(0)" id="<?php echo $agency_brands['id']; ?>"> <span id="edit-activator" class="button">ذخیره</span> </a>
           <a class="ens_brand_<?php echo $agency_brands['id']; ?>" href="javascript:void(0)" style="display:none"  id="<?php echo $agency_brands['id']; ?>"> <span id="edit-activator" class="button">انصراف</span>    </a>
           </span>
          </td>
           </tr>
           <?php
          }//end foreach img_events
       }
       ?>
          </table>
          <?php
         $num_of_pages = ceil($total/$limit);
         $end = $start + $num_of_pages;
         $end = (sizeof($agency_brands) < $end) ? sizeof($agency_brands) : $end;
         $pagination_args = array
          (
         'base' => @add_query_arg('paged','%#%'),
         'format' => '?page=%#%',
         'total' => $num_of_pages,
         'current' => $pagenum,
         'show_all' => True,
         'prev_next'    => True,
         'prev_text'    => __('«'),
         'next_text'    => __('»'),
         'type' => 'plain',
         'add_args'     => False
          );
         echo '<DIV class="tablenav-pages"><span class="displaying-num"></span>';
         echo paginate_links($pagination_args);
         echo"</div>";



?>
</div>
</div>
</div><!-- end agency_box -->