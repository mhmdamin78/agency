<?php
if ( ! defined('ABSPATH')) exit('restricted access');

if(isset($_GET['settings-updated']))
{

echo '<div id="message" class="updated">
<p style="color:red;font-size:13px">تنظیمات با موفقیت ذخیره شد</p>
</div>';
}


?>
<div class="agency_box">
 <div class="agency_titr"><span>پیکربندی افزونه نمایندگان</span>
  <div class="agency_fil_left">
  <a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=add_agency"><img src="<?php echo plugins_url('agency/images/add-user.png'); ?>" width='' alt="افزدون نماینده" title="افزودن نماینده" /></a>
  <a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=add_agency"><img src="<?php echo plugins_url('agency/images/agency_list1.png'); ?>" width=''  alt="لیست نمایندگان" title="لیست نمایندگان" /></a>
  </div>
 </div>
 <div class="agency_container">
 <ul class="agency_tabs">
		<li class="tab-link current" data-tab="tab-1">تنظیمات کلی</li>
		<li class="tab-link" data-tab="tab-2">استایل سفارشی</li>
        <li class="tab-link" data-tab="tab-3">ارتقا نسخه</li>
	</ul>
 <div id="tab-1" class="ag_tab_content current">
<form method="post" action="options.php">
<table id="agency_tbl_setting">
            <?php settings_fields('agency_options');
            ?>
 <tr>
 <th>تنظیمات نمایش فیلدها</th>
 </tr>
 <tr>
           <td>نام مدیر عامل:</td>
            <td><select name="agency_fname">
            <option <?php if(get_option('agency_fname')=="yes")echo ' selected="selected"'; ?>   value="yes">نمایش </option>
            <option <?php if(get_option('agency_fname')=="no")echo ' selected="selected"'; ?> value="no">مخفی</option>
            </select>
            </td>
           </tr>
               <tr>
            <td>تلفن همراه:</td>
            <td><select name="agency_mobile">
           <option <?php if(get_option('agency_mobile')=="yes")echo ' selected="selected"'; ?>   value="yes">نمایش </option>
            <option <?php if(get_option('agency_mobile')=="no")echo ' selected="selected"'; ?> value="no">مخفی</option>
            </select>
            </td>
            </tr>
                <tr>
           <td>نوع نمایندگی:</td>
            <td><select name="agency_type">
            <option <?php if(get_option('agency_type')=="yes")echo ' selected="selected"'; ?>   value="yes">نمایش </option>
            <option <?php if(get_option('agency_type')=="no")echo ' selected="selected"'; ?> value="no">مخفی</option>
            </select>
            </td>
           </tr>
            <tr>
            <tr>
            <td>شماره تلفن:</td>
            <td><select name="agency_phone">
           <option <?php if(get_option('agency_phone')=="yes")echo ' selected="selected"'; ?>   value="yes">نمایش </option>
            <option <?php if(get_option('agency_phone')=="no")echo ' selected="selected"'; ?> value="no">مخفی</option>
            </select>
            </td>
            </tr>
                <tr>
            <td>شماره فکس:</td>
             <td><select name="agency_fax">
        <option <?php if(get_option('agency_fax')=="yes")echo ' selected="selected"'; ?>   value="yes">نمایش </option>
            <option <?php if(get_option('agency_fax')=="no")echo ' selected="selected"'; ?> value="no">مخفی</option>
            </select>
            </td>
            </tr>
               <tr>
            <td>ایمیل:</td>
             <td><select name="agency_mail">
         <option <?php if(get_option('agency_mail')=="yes")echo ' selected="selected"'; ?>   value="yes">نمایش </option>
            <option <?php if(get_option('agency_mail')=="no")echo ' selected="selected"'; ?> value="no">مخفی</option>
            </select>
            </td>
            </tr>
               <tr>
            <td>وبسایت:</td>
             <td><select name="agency_site">
         <option <?php if(get_option('agency_site')=="yes")echo ' selected="selected"'; ?>   value="yes">نمایش </option>
            <option <?php if(get_option('agency_site')=="no")echo ' selected="selected"'; ?> value="no">مخفی</option>
            </select>
            </td>
            </tr>
            <tr>
            <td>کد پستی:</td>
             <td><select name="agency_postcode">
        <option <?php if(get_option('agency_postcode')=="yes")echo ' selected="selected"'; ?>   value="yes">نمایش </option>
            <option <?php if(get_option('agency_postcode')=="no")echo ' selected="selected"'; ?> value="no">مخفی</option>
            </select>
            </td>
            </tr>
            <tr>
            <td>حوزه های فعالیت:</td>
             <td><select name="agency_brands">
         <option <?php if(get_option('agency_brands')=="yes")echo ' selected="selected"'; ?>   value="yes">نمایش </option>
            <option <?php if(get_option('agency_brands')=="no")echo ' selected="selected"'; ?> value="no">مخفی</option>
            </select>
            </td>
            </tr>

            <tr>
            <td>شبکه های اجتماعی:</td>
             <td><select name="agency_social">
         <option <?php if(get_option('agency_social')=="yes")echo ' selected="selected"'; ?>   value="yes">نمایش </option>
            <option <?php if(get_option('agency_social')=="no")echo ' selected="selected"'; ?> value="no">مخفی</option>
            </select>
            </td>
            </tr>
                <tr>
            <td>نمایش راهنمای نقشه:</td>
             <td><select name="agency_help_color">
         <option <?php if(get_option('agency_help_color')=="yes")echo ' selected="selected"'; ?>   value="yes">نمایش </option>
            <option <?php if(get_option('agency_help_color')=="no")echo ' selected="selected"'; ?> value="no">مخفی</option>
            </select>
            </td>
            </tr>
             <tr>
            <td>متن پیام برای استان های فاقد نماینده:</td>
             <td>
             <textarea name="agency_message_pno" cols="40" rows="3"><?php echo get_option('agency_message_pno');?></textarea>
            </td>
            </tr>

</table>
<table id="agency_tbl_setting">
 <tr>
 <th>تنظیمات صفحه مدیریت</th>
 </tr>
 <tr>
           <td>تعداد نماینده در هر صفحه:</td>
            <td><select name="agency_count">
            <?php
            $i=8;
            for($i;$i<=20;$i++){
                ?>
             <option <?php if(get_option('agency_count')==$i)echo ' selected="selected"'; ?> value="<?php echo $i ?>" ><?php echo $i ?></option>

            <?php

            }
            ?>


            </select>
            </td>
           </tr>
           <tr>
           <td></td>
           <td> <input type="submit"  class="btn_agency  ag-success"   value="ذخیره"/>   </td>
           </tr>
</table>


</form>
</div>
	<div id="tab-2" class="ag_tab_content">
   <form method="post" action="options.php">
<table id="agency_tbl_setting">
            <?php settings_fields('agency_css_options');
            ?>
 <tr>
 <th>رنگ بندی </th>
 </tr>

  <tr>
<td>رنگ زمینه لیست استان ها :</td>
<td><input type="text" name="agency_list_color" class="jscolor" value=<?php echo get_option("agency_list_color");?> ></td>
</tr>
  <tr>
<td>رنگ زمینه هاور لیست استان ها:</td>
<td><input type="text" name="agency_list_hcolor" class="jscolor" value=<?php echo get_option("agency_list_hcolor");?> ></td>
</tr>
  <tr>
<td>رنگ لیست شهرها:</td>
<td><input type="text" name="agency_city_color" class="jscolor" value=<?php echo get_option("agency_city_color");?> ></td>
</tr>
  <tr>
<td>رنگ هاور لیست شهرها:</td>
<td><input type="text" name="agency_city_hcolor" class="jscolor" value=<?php echo get_option("agency_city_hcolor");?> ></td>
</tr>
  <tr>
<td>رنگ استان های دارای نماینده:</td>
<td><input type="text" name="agency_map_pfound_color" class="jscolor" value=<?php echo get_option("agency_map_pfound_color");?> ></td>
</tr>
  <tr>
<td>رنگ هاور استان های دارای نماینده:</td>
<td><input type="text" name="agency_map_pfound_hcolor" class="jscolor" value=<?php echo get_option("agency_map_pfound_hcolor");?> ></td>
</tr>
  <tr>
  <tr>
<td>رنگ استان های بدون نماینده:</td>
<td><input type="text" name="agency_map_pno_color" class="jscolor" value=<?php echo get_option("agency_map_pno_color");?> ></td>
</tr>
<tr>
<td>رنگ هاور استان های بدون نماینده:</td>
<td><input type="text" name="agency_map_pno_hcolor" class="jscolor" value=<?php echo get_option("agency_map_pno_hcolor");?> ></td>
</tr>
           <tr>
           <td></td>
           <td> <input type="submit"  class="btn_agency  ag-success"   value="ذخیره"/>   </td>
           </tr>
</table>


</form>
</div>
 <div id="tab-3" class="ag_tab_content">
<div class="agency_danger">
 <p>
 کاربر گرامی اگر شما قبلا از نسخه های 1.2 و پایین تر افزونه نمایندگان استفاده می کردید و الان قصد ارتقائ نسخه خودهستید
 کارهای زیر را انجام دهید.
 </p>
 <P>البته سیستم افزونه به طور خودکار نسخه افزونه را تشخیص می دهد و در صورت نیاز این کار را انجام خواهد داد</P>
 </div>
 <?php
 global $wpdb;
 $table_name=$wpdb->prefix."agency_list";
 $rwe=$wpdb->query("SHOW COLUMNS FROM  $table_name LIKE 'a_postcode'");
if($rwe) {
echo"<b>خوشبختانه نسخه افزونه به روز می باشد و نیازی به ارتقا نسخه افزونه ندارید</b>";
}
else
{
?>
<div class="upgrade_res"></div>
<input class="btn_agency  ag-success"  id="upgrade_agency"  value="ارتقا نسخه" />
<?php
}
 ?>


</div>


</div>


</div>