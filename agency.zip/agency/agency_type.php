<?php
if ( ! defined('ABSPATH')) exit('restricted access');
global $wpdb;
$table_name=$wpdb->prefix."agency_type";
  if(isset($_POST['submit_type']) && !(isset($_GET['action'])))
   {
      if(!empty($_POST['type_name']))
     {
      $result=$wpdb->insert($table_name,array('name'=>$_POST['type_name']),array('%s'));
      if($result)
       {
        echo '<div id="message" class="updated"><p style="color:red">نوع نمایندگی با موفقیت اضافه شد</p></div>';
       }//end result
       else
       {
        echo '<div class="error"><p style="color:red">مشکلی در ثبت نوع نمایندگی به وجود آمد لطفا دوباره تلاش کنید</p></div>';
       }// else result
     }//end if brand_name
    else
     {
      echo '<div class="error"><p style="color:red">لطفا عنوانی برای نوع نمایندگی انتخاب کنید</p></div>';
     }//end else brand_name
   }// end action add
?>
<div id="agency_res"></div>
<div class="agency_box">
<div class="agency_title">لیست نوع نمایندگی ها</div>
<div>
<div class="agency-brands-right">
  <form name="brand" method="post" id="#agency_type">
    <table>
    <tr>
    <td><input type="text" name="type_name"  placeholder="افزودن نوع نمایندگی" id="type_name" value="" /><span class="agency_nec"></span></td>
    <td> <input  type="submit"  class="btn_agency  ag-success" name="submit_type" value="ذخیره" /></td>
    </tr>
   </table>
 </form>
</div>
<div class="agency-brands-left">
<?php

  $pagenum = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
  $limit = get_option("agency_count"); // number of rows in page
  $offset =($pagenum-1) * $limit;
?>
  <div id="agency_fil">
  <div class="agency_fil_right">
     <form  method="get" action="">
      <input type="hidden"  name="page" value="agency_type" />
      <input type="text" name="s" id="aserach"  value="" placeholder="جست و جو"/>
      <input type="submit" name="submit_state" value="صافی" />
     </form>
  </div>
  <div class="agency_fil_left">
    <a href="#" id="del_" class="del_agency_type">حذف نوع نمایندگی</a>
  </div>
  </div>
     <table id="tbl_list_agency">
       <tr>
       <th><input type="checkbox" id="checkAll"/></th>
       <th>عنوان نوع نمایندگی</th>
       <th>عملیات</th>
       </tr>
       <?php
       if(isset($_GET['s']) && $_GET['s']!="")
     {
       $i=0;
       $s=$_GET['s'];
       $agency_type=$wpdb->get_results("SELECT * FROM $table_name WHERE name LIKE '%$s%'  LIMIT  $offset, $limit",ARRAY_A);
       $total= $wpdb->get_var( "SELECT COUNT(`id`) FROM $table_name WHERE name LIKE '%$s%';");



         foreach($agency_type as $agency_type)
          {
       $i++;
         ?>
           <tr id="<?php echo $agency_type['id']; ?>">
           <td class="center"><input type="checkbox" name="check_list[]" value="<?php echo $agency_type['id']; ?>" /></td>
           <td>
           <input type="text" id="type_name_<?php echo $agency_type['id']; ?>" value="<?php echo $agency_type['name'];?>" disabled="disabled" class="cat_name_db" />
           </td>
           <td>
           <span class="type_list">
           <a class="edit_type_<?php echo $agency_type['id']; ?>" href="javascript:void(0)" id="<?php echo $agency_type['id']; ?>"> <span id="edit-activator" class="button">ویرایش</span>    </a>
          <a class="save_type_<?php echo $agency_type['id']; ?>" style="display:none" href="javascript:void(0)" id="<?php echo $agency_type['id']; ?>"> <span id="edit-activator" class="button">ذخیره</span> </a>
           <a class="ens_type_<?php echo $agency_type['id']; ?>" href="javascript:void(0)" style="display:none"  id="<?php echo $agency_type['id']; ?>"> <span id="edit-activator" class="button">انصراف</span>    </a>
           </span>
          </td>
           </tr>
           <?php
          }//end foreach img_events
          }//end if sGET
          else
          {
         $i=0;
         $agency_type=$wpdb->get_results("SELECT * FROM $table_name LIMIT  $offset, $limit",ARRAY_A);
         $total = $wpdb->get_var( "SELECT COUNT(`id`) FROM $table_name");
         foreach($agency_type as $agency_type)
          {
           $i++;
         ?>
           <tr id="<?php echo $agency_type['id']; ?>">
           <td class="center"><input type="checkbox" name="check_list[]" value="<?php echo $agency_type['id']; ?>" /></td>
           <td>
           <input type="text" id="type_name_<?php echo $agency_type['id']; ?>" value="<?php echo $agency_type['name'];?>" disabled="disabled" class="cat_name_db" />
           </td>
           <td>
           <span class="type_list">
           <a class="edit_type_<?php echo $agency_type['id']; ?>" href="javascript:void(0)" id="<?php echo $agency_type['id']; ?>"> <span id="edit-activator" class="button">ویرایش</span>    </a>
          <a class="save_type_<?php echo $agency_type['id']; ?>" style="display:none" href="javascript:void(0)" id="<?php echo $agency_type['id']; ?>"> <span id="edit-activator" class="button">ذخیره</span> </a>
           <a class="ens_type_<?php echo $agency_type['id']; ?>" href="javascript:void(0)" style="display:none"  id="<?php echo $agency_type['id']; ?>"> <span id="edit-activator" class="button">انصراف</span>    </a>
           </span>
          </td>
           </tr>
           <?php
          }//end foreach img_events
       }
       ?>
          </table>
          <?php
         $num_of_pages = ceil($total/$limit);
         $end = $start + $num_of_pages;
         $end = (sizeof($agency_type) < $end) ? sizeof($agency_type) : $end;
         $pagination_args = array
          (
         'base' => @add_query_arg('paged','%#%'),
         'format' => '?page=%#%',
         'total' => $num_of_pages,
         'current' => $pagenum,
         'show_all' => True,
         'prev_next'    => True,
         'prev_text'    => __('«'),
         'next_text'    => __('»'),
         'type' => 'plain',
         'add_args'     => False
          );
         echo '<DIV class="tablenav-pages"><span class="displaying-num"></span>';
         echo paginate_links($pagination_args);
         echo"</div>";



?>
</div>
</div>
</div><!-- end agency_box -->