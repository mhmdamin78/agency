<?php
if ( ! defined('ABSPATH')) exit('restricted access');
?>
 <div id="agency_res"></div>
<div class="agency_box">
<div class="agency_title">لیست نمایندگان</div>
<div></div>
<?php
$pagenum = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
$limit = get_option("agency_count"); // number of rows in page
$offset =($pagenum-1) * $limit;
global $wpdb;
$table_name=$wpdb->prefix."agency_list";
$a_state=null;
if(isset($_GET['a_state']) && $_GET['a_state']!="all")
 {
       $a_state=$_GET['a_state'];
       if(isset($_GET['city']) && $_GET['city']!="all")
       {
         $city=$_GET['city'];
         if(isset($_GET['s']) && $_GET['s']!="")
         {
          $search=$_GET['s'];
          $total = $wpdb->get_var( "SELECT COUNT(`id`) FROM $table_name WHERE (a_name LIKE '%$search%' OR a_fname LIKE '%$search%') AND a_state=$a_state AND a_city='$city'");
          $agency=$wpdb->get_results("SELECT * FROM $table_name WHERE (a_name LIKE '%$search%' OR a_fname LIKE '%$search%') AND  a_state=$a_state AND a_city='$city' LIMIT $offset,$limit",ARRAY_A);

         }//end if s
         else
         {
          $total = $wpdb->get_var( "SELECT COUNT(`id`) FROM $table_name WHERE a_state=$a_state AND a_city='$city'");
          $agency=$wpdb->get_results("SELECT * FROM $table_name WHERE a_state=$a_state AND a_city='$city' LIMIT $offset,$limit",ARRAY_A);
         }//end else s
      }//end if city
      else
      {
         if(isset($_GET['s']) && $_GET['s']!="")
         {
          $total = $wpdb->get_var( "SELECT COUNT(`id`) FROM $table_name WHERE (a_name LIKE '%$search%' OR a_fname LIKE '%$search%') AND a_state=$a_state");
          $agency=$wpdb->get_results("SELECT * FROM $table_name  WHERE (a_name LIKE '%$search%' OR a_fname LIKE '%$search%') AND  a_state=$a_state LIMIT $offset,$limit",ARRAY_A);
         }//end if s
         else
         {
          $total = $wpdb->get_var( "SELECT COUNT(`id`) FROM $table_name WHERE a_state=$a_state");
          $agency=$wpdb->get_results("SELECT * FROM $table_name WHERE a_state=$a_state LIMIT $offset,$limit",ARRAY_A);

         }//end else s

      }//end else city


}//end if a_state
else
{
    if(isset($_GET['s']) && $_GET['s']!="")
     {
      $search=$_GET['s'];
      $agency=$wpdb->get_results("SELECT * FROM $table_name WHERE a_name LIKE '%$search%' OR a_fname LIKE '%$search%'  LIMIT  $offset, $limit",ARRAY_A);
      $total= $wpdb->get_var( "SELECT COUNT(`id`) FROM $table_name WHERE a_name LIKE '%$search%' OR a_fname LIKE '%$search%' ;");


      }//end if s
    else
      {
        $total = $wpdb->get_var( "SELECT COUNT(`id`) FROM $table_name");
         $agency=$wpdb->get_results("SELECT * FROM $table_name LIMIT  $offset, $limit",ARRAY_A);
      }//end else s

}//end else  a_state
if(1)
 {
$list_ostan[0]='agency';

?>
  <div id="agency_fil">
  <div class="agency_fil_right">
  <form method="get" action="">
  <input type="hidden"  name="page" value="agency" />
  <select id="a_state" name="a_state">
  <option <?php if($a_state=="all")echo ' selected="selected"'; ?>  value="all">همه استان ها</option>
  <?php
   $agency_state=$wpdb->get_results('SELECT * FROM '.$wpdb->prefix."agency_state".' ORDER BY id ASC',ARRAY_A);
   foreach($agency_state as $agency_state)
    {
    $besh=$agency_state['id'];
    $list_ostan[$besh]=$agency_state['name'];
  ?>
     <option <?php if($a_state==$agency_state['id'])echo ' selected="selected"'; ?> value="<?php echo $agency_state['id']; ?>"><?php echo $agency_state['name']; ?></option>
     <?php } ?>
  </select>
  <span id="agency_lcity">
  <?php
  if(isset($_GET['city']))
  {
  $city=$_GET['city'];
  $id=$_GET['a_state'];
  $table_name=$wpdb->prefix."agency_list";
  $agency_one=$wpdb->get_results('SELECT DISTINCT a_city FROM '.$table_name.' WHERE a_state='.$id.' ORDER BY a_city',ARRAY_A);
  if(sizeof($agency_one)!=0)
     {
    echo"<select name='city'>";
    ?>
    <option <?php if($city=="all")echo ' selected="selected"'; ?>  value="all">تمام شهرها</option>
      <?php
       foreach($agency_one as $agency_one)
       {
      ?>
        <option <?php if($city==$agency_one['a_city'])echo ' selected="selected"'; ?> value="<?php echo $agency_one['a_city']; ?>"><?php echo $agency_one['a_city']; ?></option>
      <?php
      }//end foreach

      echo"</select>";

      }//end if

    }//end if city
    ?>
     </span>
     <input type="text" name="s" id="agency_serach"  value="" placeholder="جست و جو"/>
     <input type="submit" name="submit_state" value="صافی" />
     </form>
     </div>
     <div class="agency_fil_left">
     <a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=add_agency"><img src="<?php echo plugins_url('agency/images/add-user.png'); ?>"  alt="افزدون نماینده" title="افزودن نماینده"/></a>
    <a href="#" class="del_agency"><img src="<?php echo plugins_url('agency/images/remove-user.png'); ?>"  alt="حذف نماینده" title="حذف نماینده" /></a>

     </div>
     </div>
     <table id="tbl_list_agency">
      <tr>
       <th><input type="checkbox" id="checkAll"/></th>
       <th>نام نمایندگی</th>
       <th>نام مدیر عامل</th>
       <th>استان</th>
       <th>شماره تلفن</th>
       <th>عملیات</th>
       </tr>
       <?php
       $i=0;

         foreach($agency as $agency)
          {
           $i++;
           $id_state=$agency['a_state'];
         ?>
           <tr id="<?php echo $agency['id']; ?>">
           <td class="center"><input type="checkbox" name="check_list[]" value="<?php echo $agency['id']; ?>" /></td>
           <td><a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=add_agency&action=edit&id=<?php echo $agency['id'] ?>"  id="<?php echo $agency['id'] ?>"><?php echo $agency['a_name']; ?></a></td>
           <td><?php echo $agency['a_fname']; ?></td>
            <td><?php echo $list_ostan[$id_state]; ?></td>
           <td class="center"><?php echo $agency['a_phone']; ?></td>
           <td class="center">
           <a href="javascript:void(0)" class="ditail_agency" id="<?php echo $agency['id']; ?>"><img src="<?php echo plugins_url('agency/images/user-view.png'); ?>" width='25px' alt="مشاهده نماینده" title="مشاهده نماینده" /></a>
           <a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=add_agency&action=edit&id=<?php echo $agency['id'] ?>" id="<?php echo $agency['id']; ?>"><img src="<?php echo plugins_url('agency/images/edit-icon.png'); ?>" width='25px' alt="ویرایش" title="ویرایش" /></a>
           </td>
           </tr>
           <?php
          }//end foreach agency

           ?>
          </table>
          <?php
         $num_of_pages = ceil($total/$limit);
         $end = $num_of_pages;
         $end = (sizeof($agency) < $end) ? sizeof($agency) : $end;
         $pagination_args = array
          (
         'base' => @add_query_arg('paged','%#%'),
         'format' => '?page=%#%',
         'total' => $num_of_pages,
         'current' => $pagenum,
         'show_all' => False,
         'end_size'           => 1,
         'mid_size'           => 4,
         'prev_next'    => True,
         'prev_text'    => __('«'),
         'next_text'    => __('»'),
         'type' => 'plain',
         'add_args'     => False
          );
         echo '<DIV class="tablenav-pages"><span class="displaying-num"></span>';
         echo paginate_links($pagination_args);
         echo"</div>";
}
?>
       <div id="agency_load"></div>
      <div  id="agency_joz"></div>
      </div>