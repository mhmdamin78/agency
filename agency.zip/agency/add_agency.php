<?php
if ( ! defined('ABSPATH')) exit('restricted access');
global $wpdb;
if(isset($_POST['submit_agency']))
   {
    if(!empty($_POST['a_state']) && !empty($_POST['a_city']) && !empty($_POST['a_name']))
    {
    $a_date=mt_rand(1,10000)+mt_rand(11000,30000);
     $table_name=$wpdb->prefix."agency_list";
      $a_site="";
       if($_POST["a_site"]!="")
       {
          $a_site=str_replace('http://','',$_POST['a_site']);
       }
     if(isset($_POST['brands']))
      {
          foreach($_POST['brands'] as $brands)
         {
           $brands_agency.=$brands.',';
         }
     }//end isset brands
     if(isset($_GET['action']) && isset($_GET['id']) && $_GET['action']=="edit")
     {
        $table_name=$wpdb->prefix."agency_list";
        $id=$_GET['id'];
        $a_name=$_POST['a_name'];
        $result_edit=$wpdb->update($table_name,array('a_name'=>$a_name,'a_fname'=>$_POST['a_fname'],'a_state'=>$_POST['a_state'],'a_city'=>$_POST['a_city'],'a_phone'=>$_POST['a_phone'],'a_fax'=>$_POST['a_fax'],'a_mobile'=>$_POST['a_mobile'],'a_site'=>$a_site,'a_email'=>$_POST['a_email'],'a_address'=>$_POST['a_address'],'a_date'=>$a_date,'a_brands'=>$brands_agency,'a_telegram'=>$_POST['a_telegram'],'a_instagram'=>$_POST['a_instagram'],'a_facebook'=>$_POST['a_facebook'],'a_google'=>$_POST['a_google'],'a_aparat'=>$_POST['a_aparat'],'a_type'=>$_POST['a_type'],'a_postcode'=>$_POST['a_postcode']),array('id'=> $id),array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s','%s','%s','%s','%s','%s','%s'));
      }//end if edit
     else
       {


        $result=$wpdb->insert($table_name,array('a_name'=>$_POST['a_name'],'a_fname'=>$_POST['a_fname'],'a_state'=>$_POST['a_state'],'a_city'=>$_POST['a_city'],'a_phone'=>$_POST['a_phone'],'a_fax'=>$_POST['a_fax'],'a_mobile'=>$_POST['a_mobile'],'a_site'=>$a_site,'a_email'=>$_POST['a_email'],'a_address'=>$_POST['a_address'],'a_date'=>$a_date,'a_brands'=>$brands_agency,'a_telegram'=>$_POST['a_telegram'],'a_instagram'=>$_POST['a_instagram'],'a_facebook'=>$_POST['a_facebook'],'a_google'=>$_POST['a_google'],'a_aparat'=>$_POST['a_aparat'],'a_type'=>$_POST['a_type'],'a_postcode'=>$_POST['a_postcode']),array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s','%s','%s','%s','%s','%s','%s'));
       }//end else edit
      if ($result_edit)
       {
        echo '<div id="message" class="updated"><p style="color:red">اطلاعات نماینده با موفقیت  به روز رسانی شد.</p></div>';
       }//end if result_edit
      else if($result)
       {
      echo '<div id="message" class="updated"><p style="color:red">مشخصات نماینده با موفقیت ذخیره شد</p></div>';
       }
       else
       {
        echo '<div class="error"><p style="color:red"> مشکلی در ثبت نماینده به وجود آمده لطفا دوباره تلاش کنید.</p></div>';
       }
    }//end if a_state
     else
    {
       echo '<div class="error"><p style="color:red;padding:10px">    لطفا تمام فیلدهای ضروری را پر کنید  </p></div>';

    }
}//end isset submit
  if(isset($_GET['action']))
  {
  $id=$_GET['id'];
  $table_name=$wpdb->prefix."agency_list";
  $agency=$wpdb->get_row('SELECT * FROM '.$table_name.' WHERE id='.$id,ARRAY_A);
  }
  else
  {
   $agency=array('a_name'=>'','a_fname'=>'','a_state'=>'','a_city'=>'','a_phone'=>'','a_fax'=>'','a_mobile'=>'','a_site'=>'','a_email'=>'','a_address'=>'','a_date'=>'','a_brands'=>'','a_telegram'=>'','a_instagram'=>'','a_facebook'=>'','a_google'=>'','a_aparat'=>'','a_type'=>'','a_postcode'=>'');
  }
?>

<div class="agency_box">
<div class="agency_title">
<span>مشخصات نمایندگی</span>
<div class="agency_fil_left">
<a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=agency"><img src="<?php echo plugins_url('agency/images/agency_list.png'); ?>" width='' alt="لیست نمایندگان" title="لیست نمایندگان" /></a>
 </div>
</div>

   <form method="post">
   <table id="tbl_add_agency">
    <tr>
     <td>استان:</td>
     <td>
      <select name="a_state">
      <?php
      $agency_state=$wpdb->get_results('SELECT * FROM '.$wpdb->prefix."agency_state".' ORDER BY id ASC',ARRAY_A);
      foreach($agency_state as $agency_state)
       {
       ?>
      <option <?php if($agency_state['id']==$agency['a_state'])echo 'selected="selected"';?>value="<?php echo $agency_state['id']; ?>"><?php echo $agency_state['name']; ?></option>
      <?php
       }//end foreach
      ?>
     </select>
     <span class="agency_nec">*</span>
    </td>
    </tr>
     <tr>
      <td>شهر:</td>
      <td><input type="text" name="a_city" id="a_city" value="<?php echo $agency['a_city'];?>" /><span class="agency_nec">*</span></td>
     </tr>
     <tr>
      <td>نام شرکت:</td>
      <td><input type="text" name="a_name" id="a_name" value="<?php echo $agency['a_name'];?>" /><span class="agency_nec">*</span></td>
    </tr>
    <tr>
     <td>نوع نمایندگی:</td>
     <td>
      <select name="a_type">
      <?php
      $agency_type=$wpdb->get_results('SELECT * FROM '.$wpdb->prefix."agency_type".' ORDER BY id ASC',ARRAY_A);
      foreach($agency_type as $agency_type)
       {
       ?>
      <option <?php if($agency_type['id']==$agency['a_type'])echo 'selected="selected"';?>value="<?php echo $agency_type['id']; ?>"><?php echo $agency_type['name']; ?></option>
      <?php
       }//end foreach
      ?>
     </select>
    </td>
    </tr>
    <tr>
     <td>نام و نام خانوادگی مدیر عامل:</td>
     <td><input type="text" name="a_fname" id="a_fname" value="<?php echo $agency['a_fname'];?>" /></td>
   </tr>
   <tr>
    <td>شماره تلفن:</td>
    <td><input type="text" name="a_phone" id="a_phone" value="<?php echo $agency['a_phone'];?>" /></td>
   </tr>
   <tr>
    <td>شماره فکس:</td>
    <td><input type="text" name="a_fax" id="a_fax" value="<?php echo $agency['a_fax'];?>" /></td>
   </tr>
   <tr>
    <td>تلفن همراه:</td>
    <td><input type="text" name="a_mobile" id="a_mobile" maxlength="11" value="<?php echo $agency['a_mobile'];?>" /></td>
  </tr>
  <tr>
   <td>ایمیل:</td>
   <td><input type="text" name="a_email" id="a_email" value="<?php echo $agency['a_email'];?>" /></td>
  </tr>
  <tr>
   <td>وبسایت:</td>
   <td><input type="text" name="a_site" id="a_site" value="<?php echo $agency['a_site'];?>" /><span class="redBold">://http</span></td>
  </tr>
   <tr>
    <td>آدرس:</td>
    <td><textarea name="a_address" cols="40" rows=5" id="a_address"><?php echo $agency['a_address'];?></textarea></td>
  </tr>
    <tr>
   <td>کد پستی:</td>
   <td><input type="text" name="a_postcode" id="a_postcode" value="<?php echo $agency['a_postcode'];?>" /></td>
  </tr>
    <tr>
   <td>تلگرام:</td>
   <td><input type="text" name="a_telegram" id="a_telegram" value="<?php echo $agency['a_telegram'];?>" /></td>
  </tr>
     <tr>
   <td>اینستاگرام:</td>
   <td><input type="text" name="a_instagram" id="a_instagram" value="<?php echo $agency['a_instagram'];?>" /></td>
  </tr>
       <tr>
   <td>فیسبوک:</td>
   <td><input type="text" name="a_facebook" id="a_facebook" value="<?php echo $agency['a_facebook'];?>" /></td>
  </tr>
  <tr>
   <td>آپارات:</td>
   <td><input type="text" name="a_aparat" id="a_aparat" value="<?php echo $agency['a_aparat'];?>" /></td>
  </tr>
    <tr>
   <td>گوگل پلاس:</td>
   <td><input type="text" name="a_google" id="a_google" value="<?php echo $agency['a_aparat'];?>" /></td>
  </tr>
  <tr>
  <td>حوزه های فعالیت:</td>
     <td>
      <?php
     $ar_brand=explode(",",$agency['a_brands']);
      $agency_brands=$wpdb->get_results('SELECT * FROM '.$wpdb->prefix."agency_brands".' ORDER BY id ASC',ARRAY_A);
      foreach($agency_brands as $agency_brands)
       {
       ?>
      <input type="checkbox" name="brands[]" <?php if(in_array($agency_brands['id'],$ar_brand)) {echo 'checked="checked"';} ?>  value="<?php echo $agency_brands['id'];?>" /> <?php if($agency_brands['id'])?><?php echo $agency_brands['name']; ?>
      <?php
       }//end foreach
      ?>
    </td>

  </tr>
   <tr>
    <td style="background:#fff"></td>
    <td colspan="2"><input type="submit" id="submit"   class="btn_agency  ag-success" name="submit_agency" value="ذخیره" /></td>
  </tr>
  </table>
  </form>
  </div>