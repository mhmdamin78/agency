<?php
if ( ! defined('ABSPATH')) exit('restricted access');
agency::init();
class agency {
 public static function init(){
register_activation_hook(__file__,array(__class__,'install'));
register_uninstall_hook(__FILE__, 'agency_unistall');
add_action('admin_menu',array(__class__,'admin_menu'));
add_action('admin_enqueue_scripts',array(__class__,'admin_enqueue_scripts'));
add_action('wp_ajax_del_agency',array(__class__,'del_agency'));
add_action('wp_ajax_nopriv_del_agency',array(__class__,'del_agency'));
add_action('wp_ajax_ditail_agency',array(__class__,'ditail_agency'));
add_action('wp_ajax_nopriv_ditail_agency',array(__class__,'ditail_agency'));
add_action('wp_ajax_city_agency',array(__class__,'city_agency'));
add_action('wp_ajax_nopriv_city_agency',array(__class__,'city_agency'));
add_action('wp_ajax_list_agency',array(__class__,'list_agency'));
add_action('wp_ajax_nopriv_list_agency',array(__class__,'list_agency'));
add_action('wp_ajax_city',array(__class__,'city'));
add_action('wp_ajax_nopriv_city',array(__class__,'city'));
add_action('wp_ajax_upgrade_agency',array(__class__,'upgrade_agency'));
add_action('wp_ajax_nopriv_upgrade_agency',array(__class__,'upgrade_agency'));
add_action('wp_ajax_edit_brands_agency',array(__class__,'edit_brands_agency'));
add_action('wp_ajax_nopriv_edit_brands_agency',array(__class__,'edit_brands_agency'));
add_action('wp_ajax_edit_type_agency',array(__class__,'edit_type_agency'));
add_action('wp_ajax_nopriv_edit_type_agency',array(__class__,'edit_type_agency'));
add_action('wp_ajax_self_agency',array(__class__,'self_agency'));
add_action('wp_ajax_nopriv_self_agency',array(__class__,'self_agency'));
add_action('wp_ajax_search_agency',array(__class__,'search_agency'));
add_action('wp_ajax_nopriv_search_agency',array(__class__,'search_agency'));
add_action('wp_enqueue_scripts',array(__class__,'plugin_file'));
add_shortcode('wp_agency_link',array(__class__,'wp_agency_link'));
add_action('wp_ajax_del_agency_brands',array(__class__,'del_agency_brands'));
add_action('wp_ajax_nopriv_del_agency_brands',array(__class__,'del_agency_brands'));
add_action('wp_ajax_del_agency_type',array(__class__,'del_agency_type'));
add_action('wp_ajax_nopriv_del_agency_type',array(__class__,'del_agency_type'));
add_action('admin_init',array(__class__,'admin_init'));

}//end function init

 public static function admin_menu()
  {
   add_menu_page('افزونه نمایندگان','افزونه نمایندگان','manage_options','agency',array(__class__,'wp_agency'),plugins_url('agency/images/logo.png'));
   add_submenu_page('agency','لیست نمایندگان','لیست نمایندگان','manage_options','agency',array(__class__,'wp_agency'));
   add_submenu_page('agency','افزودن نماینده','افزودن نماینده','manage_options','add_agency',array(__class__,'add_agency'));
    add_submenu_page('agency','نوع نمایندگی ها','نوع نمایندگی ها','manage_options','agency_type',array(__class__,'agency_type'));
   add_submenu_page('agency','حوزه های فعالیت','حوزه های فعالیت','manage_options','agency_brands',array(__class__,'agency_brands'));
   add_submenu_page('agency','ایجاد شورتکد','ایجاد شورتکد','manage_options','shortcode_agency',array(__class__,'shortcode_agency'));
   add_submenu_page('agency','تنظیمات','تنظیمات','manage_options','agency_setting',array(__class__,'setting'));
   } //end admin_menu func

 public static function wp_agency()
   {
      if(!empty($_REQUEST['action']) && $_REQUEST['action']=="delete")
        {
           self::del_agency();
        }
    require_once AGENCY_PLUGIN.'agency_list.php';


   }//end wp_shop func
   public static function setting()
   {

      require_once AGENCY_PLUGIN.'agency_setting.php';


     } //end setting function

  public static function agency_brands()
   {

   require_once AGENCY_PLUGIN.'agency_brands.php';


   } //end setting function
   public static function agency_type()
   {

   require_once AGENCY_PLUGIN.'agency_type.php';


   } //end setting function
     public static function shortcode_agency()
   {
   require_once AGENCY_PLUGIN.'shortcode_agency.php';
   }//end shortcode function
   public static function del_agency()
     {
       global $wpdb;
       $id=$_POST['id'];
       $ids= implode($id,',');
       $table_name=$wpdb->prefix."agency_list";
       $result=$wpdb->query("DELETE FROM  $table_name WHERE id in ($ids)");
       if($result){

         echo"نمایندگی با موفقیت حذف شد";
       }
       else{
           echo"مشکلی در حذف نمایندگی پیش آمده لطفا دوباره امتحان کنید";
       }
      die();

    } //end del_discount
     public static function del_agency_brands()
     {
       global $wpdb;
       $id=$_POST['id'];
       $ids= implode($id,',');
       $table_name=$wpdb->prefix."agency_brands";
       $result=$wpdb->query("DELETE FROM  $table_name WHERE id in ($ids)");
       if($result){

         echo"برند با موفقیت حذف شد";
       }
       else{
           echo"مشکلی در حذف برند پیش آمده لطفا دوباره تلاش کنید";
       }
      die();

    } //end del_img_events_cat


     public static function del_agency_type()
     {
       global $wpdb;
       $id=$_POST['id'];
       $ids= implode($id,',');
       $table_name=$wpdb->prefix."agency_type";
       $result=$wpdb->query("DELETE FROM  $table_name WHERE id in ($ids)");
       if($result){

         echo"نوع نمایندگی با موفقیت حذف شد";
       }
       else{
           echo "مشکلی در حذف نوع نمایندگی پیش آمده لطفا دوباره تلاش کنید";
       }
      die();

    } //end del_agency_type

     public static function edit_brands_agency()
     {
       global $wpdb;
       $id=$_POST['brand_id'];
       $brand_name=$_POST['brand_name'];
       $table_name=$wpdb->prefix."agency_brands";
       $brand=$wpdb->get_row('SELECT * FROM '.$table_name.' WHERE id='.$id,ARRAY_A);
        if( $brand['name']== $brand_name)
       {
        echo '<div id="message" class="updated"><p style="color:red">اطلاعات حوزه فعالیت به روز رسانی شد</p></div>';
       }//cat if
       else
       {
          $result=$wpdb->update($table_name,array('name'=>$brand_name),array('id'=> $id),array('%s'));
       if($result)
       {

        echo '<div id="message" class="updated"><p style="color:red">اطلاعات حوزه فعالیت به روز رسانی شد</p></div>';
       }//end if result
       else
       {
          echo '<div class="error"><p style="color:red">مشکلی در بروز رسانی  اطلاعات حوزه فعالیت به وجود آمد لطفا دوباره تلاش کنید</p></div>';
       }//end else result
       }//end else cat

      die();

    } //end edit_brands_agency

      public static function edit_type_agency()
     {
       global $wpdb;
       $id=$_POST['type_id'];
       $brand_name=$_POST['type_name'];
       $table_name=$wpdb->prefix."agency_type";
       $brand=$wpdb->get_row('SELECT * FROM '.$table_name.' WHERE id='.$id,ARRAY_A);
        if( $brand['name']== $brand_name)
       {
        echo '<div id="message" class="updated"><p style="color:red">اطلاعات نوع نمایندگی به روز رسانی شد</p></div>';
       }//cat if
       else
       {
          $result=$wpdb->update($table_name,array('name'=>$brand_name),array('id'=> $id),array('%s'));
       if($result)
       {

        echo '<div id="message" class="updated"><p style="color:red">اطلاعات نوع نمایندگی به روز رسانی شد</p></div>';
       }//end if result
       else
       {
          echo '<div class="error"><p style="color:red">مشکلی در بروز رسانی  اطلاعات نوع نمایندگی به وجود آمد لطفا دوباره تلاش کنید</p></div>';
       }//end else result
       }//end else cat

      die();

    } //end edit_type_agency

   public static function ditail_agency()
     {
       global $wpdb;
       $id=$_POST['id'];
       $table_name=$wpdb->prefix."agency_list";
       $agency=$wpdb->get_row('SELECT * FROM '.$table_name.' WHERE id='.$id,ARRAY_A);
       $table_name1=$wpdb->prefix."agency_state";
       $state=$wpdb->get_row('SELECT * FROM '.$table_name1.' WHERE id='.$agency['a_state'],ARRAY_A);
       $res='<table id="tbl_setting">
        <tr>
       <td>نام نمایندگی :</td>
       <td><input type="text" name="a_name" id="a_name" disabled="disabled" value="'.$agency['a_name'].'"   /></td>
       </tr>
        <tr>
        <td>استان:</td>
        <td>
        <input type="text" name="a_city" id="a_city" disabled="disabled" value="'.$state['name'].'" />
        </td>
        </tr>
        <tr>
       <td>شهر:</td>
       <td><input type="text" name="a_city" id="a_city" disabled="disabled" value="'.$agency['a_city'].'"/></td>
       </tr>
       <tr>
       <td>نام و نام خانوادگی مدیر عامل:</td>
       <td><input type="text" name="a_fname" id="a_fname" disabled="disabled" value="'.$agency['a_fname'].'" /></td>
       </tr>
       <tr>
       <td>شماره تلفن:</td>
       <td><input type="text" name="a_phone" id="a_phone" disabled="disabled" value="'.$agency['a_phone'].'" /></td>
       </tr>
       <tr>
       <td>شماره فکس:</td>
       <td><input type="text" name="a_phone" id="a_phone" disabled="disabled" value="'.$agency['a_phone'].'" /></td>
       </tr>
       <tr>
       <td>تلفن همراه:</td>
       <td><input type="text" name="a_mobile" id="a_mobile" disabled="disabled" value="'.$agency['a_mobile'].'" /></td>
       </tr>
       <tr>
       <td>آدرس:</td>
       <td><textarea name="a_address" disabled="disabled" cols="40" rows=5" id="a_address">'.$agency['a_address'].'</textarea></td>
       </tr>
      </table>';
    echo $res;
    die();

   }//end ditail_agency

      public static function city_agency()
      {
        global $wpdb;
        $id=$_POST['id'];
        $type=$_POST['type'];
        $table_name=$wpdb->prefix."agency_list";
        if($type=="all" && $type!=""){
          $agency=$wpdb->get_results('SELECT DISTINCT a_city FROM '.$table_name.' WHERE a_state='.$id.' ORDER BY a_city',ARRAY_A);
        }
        else{
             $type=rtrim($type,",");
             $agency=$wpdb->get_results('SELECT DISTINCT a_city FROM '.$table_name.' WHERE a_state='.$id.' AND a_type IN ('.$type.')  ORDER BY a_city',ARRAY_A);
          }
        if(sizeof($agency)!=0)
        {
          echo'<div id="agency_shahr">';
          foreach($agency as $agency)
           { ?>
          <a href="javascript:void(0)" class="city_agency" id="<?php echo $agency['id']; ?>" target="_self"  onclick="list_agency('<?php echo $agency['a_city']; ?>','<?php echo $id ?>')"><?php echo $agency['a_city']; ?></a>
        <?php
           }//end foreach
           echo"</div>";
        }//end if
        else{

            echo'<div id="agency_shahr"><span class="no-agency">'.get_option("agency_message_pno").'</span></div>';
        }
         die();

      }//end list_agency


     public static function self_agency()
      {
        global $wpdb;
        $id=$_POST['id'];
        $table_name=$wpdb->prefix."agency_list";
        $agency=$wpdb->get_row('SELECT * FROM '.$table_name.' WHERE id='.$id,ARRAY_A);
        $res='<table id="tbl_self">
              <tr>
              <td class="lable">نام نمایندگی</td>
              <td>'.$agency["a_name"].'</td>
              </tr>';
         if(get_option('agency_fname')=='yes')
         {
           $res.='<tr>
              <td class="lable">مدیرعامل</td>
              <td>'.$agency["a_fname"].'</td>
              </tr>';
         }
         $res.='<tr>
              <td class="lable">شماره تلفن:</td>
              <td>'.$agency["a_phone"].'</td>
              </tr>';
         if(get_option('agency_fax')=='yes')
         {
            $res.='<tr>
              <td class="lable">شماره فکس:</td>
              <td>'.$agency["a_phone"].'</td>
              </tr>';
         }
           if(get_option('agency_mobile')=='yes')
           {
            $res.='<tr>
              <td class="lable">تلفن همراه:</td>
              <td>'.$agency["a_mobile"].'</td>
              </tr>';
           }
            if(get_option('agency_mail')=='yes')
           {
            $res.='<tr>
             <td class="lable">ایمیل:</td>
             <td>'.$agency["a_email"].'</td>
             </tr>';
          }
         if(get_option('agency_site')=='yes')
         {
         $mystring='https://';
         if($agency["a_site"]!="")
         {
         $findme=$agency["a_site"] ;
         $pos=strpos($mystring, $findme);
           if($pos!== false)
           {
           $res.='<tr>
             <td class="lable">وبسایت:</td>
             <td><a target="_blank" href="https://'.$agency["a_site"].'">'.$agency["a_site"].'</a></td>
             </tr>';
            }
           else
           {

          $res.='<tr>
             <td class="lable">وبسایت:</td>
             <td><a target="_blank" href="http://'.$agency["a_site"].'">'.$agency["a_site"].'</a></td>
             </tr>';
           }//end else
        }//end if a_site
        else
         {
           $res.='<tr>
             <td class="lable">وبسایت:</td>
             <td></td>
              </tr>';
         }

        }// end get_option site
             $res.='<tr>
             <td class="lable">آدرس:</td>
             <td>'.$agency["a_address"].'</td>
             </tr>
             </table>';
            echo $res;
             die();
      }//end self_agency func

      public static function search_agency()
        {
           global $wpdb;
           $type_search=sanitize_text_field($_POST['type_search']);
           $search_text=sanitize_text_field($_POST['search_text']);
           $type=$_POST['type'];
           $table_name=$wpdb->prefix."agency_list";
           if($type_search=="city") {
            if($type=="all" && $type!=""){
            $agency=$wpdb->get_results("SELECT * FROM $table_name WHERE a_city='$search_text'",ARRAY_A);
            }
            else{
            $type=rtrim($type,",");
            $agency=$wpdb->get_results("SELECT * FROM $table_name WHERE a_city='$search_text' AND a_type IN ($type)",ARRAY_A);
            }
           }else if($type_search=="name")
           {
           if($type=="all" && $type!=""){
                 $agency=$wpdb->get_results("SELECT * FROM $table_name WHERE a_name LIKE '%$search_text%'",ARRAY_A);
           }
           else{
              $type=rtrim($type,",");
              $agency=$wpdb->get_results("SELECT * FROM $table_name WHERE a_name LIKE '%$search_text%' AND a_type IN ($type)",ARRAY_A);
           }

           }//else if
            $type=$wpdb->get_results('SELECT * FROM '.$wpdb->prefix."agency_type".' ORDER BY id ASC',ARRAY_A);
            $arr=array();
            if(sizeof($type)!=0)
            {
             foreach($type as $type)
            {
            $arr[$type['id']]=$type['name'];
            }
            }
         if(get_option('agency_brands')=='yes') {
           $brands=$wpdb->get_results('SELECT * FROM '.$wpdb->prefix."agency_brands".' ORDER BY id ASC',ARRAY_A);
           }
         if(sizeof($agency)!=0)
           {
             $i=0;
             foreach($agency as $agency)
             {
            if(get_option('agency_brands')=='yes') {
            $ar_brand=explode(",",$agency['a_brands']);
            foreach($brands as $brandi)
             {
              if(in_array($brandi['id'],$ar_brand))
              {
             $ali.='<li>'.$brandi['name'].'</li>';
              }
              }//end foreach
              }//end if  agency_brands
              if($i%2==0){
              $res='<div class="agency_right">';
              }
              else{
                $res='<div class="agency_left">';
              }
              $res.='<div class="agency_self">';

         $res.='<ul class="agency_ul">
              <li class="agency_lable">نام شرکت:</li>
              <li class="agency_daron">'.$agency["a_name"].'</li>
              </ul>';
          if(get_option('agency_type')=='yes')
         {
           $res.='<ul class="agency_ul">
              <li class="agency_lable">نوع نمایندگی:</li>
             <li class="agency_daron">'.$arr[$agency["a_type"]].'</li>
              </ul>';
         }
         if(get_option('agency_fname')=='yes')
         {
           $res.='<ul class="agency_ul">
              <li class="agency_lable">نام نماینده:</li>
              <li class="agency_daron">'.$agency["a_fname"].'</li>
              </ul>';
         }
               $res.='<ul class="agency_ul">
              <li class="agency_lable" id="lb_more"><i id="agencymob-'.$agency["id"].'">+</i><a href="javascript:void(0)" onclick="agency_more('.$agency["id"].')" id="agencymod-'.$agency["id"].'">اطلاعات بیشتر</a></li>
              <li class="agency_daron"></li>
              </ul>';
         $res.='<div class="agency_more" id="agencymore-'.$agency["id"].'">';
          if(get_option('agency_phone')=='yes')
         {
         $res.='<ul class="agency_ul">
              <li class="agency_lable">شماره تلفن:</li>
              <li class="agency_daron">'.$agency["a_phone"].'</li>
              </ul>';
         }
         if(get_option('agency_fax')=='yes')
         {
            $res.='<ul class="agency_ul">
              <li class="agency_lable">شماره فکس:</li>
              <li class="agency_daron">'.$agency["a_fax"].'</li>
              </ul>';
         }
           if(get_option('agency_mobile')=='yes')
           {
            $res.='<ul class="agency_ul">
              <li class="agency_lable">تلفن همراه:</li>
              <li class="agency_daron">'.$agency["a_mobile"].'</li>
              </ul>';
           }
            if(get_option('agency_mail')=='yes')
           {
            $res.='<ul class="agency_ul">
             <li class="agency_lable">ایمیل :</li>
             <li class="agency_daron">'.$agency["a_email"].'</li>
             </ul>';
          }
         if(get_option('agency_site')=='yes')
         {
         $mystring='https://';
         if($agency["a_site"]!="")
         {
         $findme=$agency["a_site"] ;
         $pos=strpos($mystring, $findme);
           if($pos!== false)
           {
           $res.='<ul class="agency_ul">
             <li class="agency_lable">وبسایت :</li>
             <li class="agency_daron"><a class="site" target="_blank" href="https://'.$agency["a_site"].'">'.$agency["a_site"].'</a></li>
             </ul>';
            }
           else
           {

          $res.='<ul class="agency_ul">
             <li class="agency_lable">وبسایت:</li>
             <li class="agency_daron"><a class="site" target="_blank" href="http://'.$agency["a_site"].'">'.$agency["a_site"].'</a></li>
             </ul>';
           }//end else
        }//end if a_site
        else
         {
           $res.='<ul class="agency_ul">
             <li class="agency_lable">وبسایت:</li>
             <li class="agency_daron"></li>
              </ul>';
         }

        }// end get_option site
            $img_url=plugins_url('agency/images/');
             $res.='<ul class="agency_ul">
             <li class="agency_lable">آدرس:</li>
             <li class="agency_daron">'.$agency["a_address"].'</li>
             </ul>';
                  if(get_option('agency_postcode')=='yes') {
              $res.='<ul class="agency_ul">
             <li class="agency_lable">کد پستی:</li>
             <li class="agency_daron">'.$agency["a_postcode"].'</li>
             </ul>';
             }
             if(get_option('agency_brands')=='yes') {
             $res.='<ul class="agency_ul">
             <li class="agency_lable">حوزه های فعالیت:</li>
             <li class="agency_daron"><ul class="agency_brands">'.$ali.'</ul></li>
             </ul>';
             }
              if(get_option('agency_social')=='yes')
         {
               $res.='<ul class="agency_ul">

            <li class="agency_daron_social">
            <ul class="agency_social_list">
            <li class="agency_social"><a  target="_blank" href="'.$agency["a_telegram"].'" titles="تلگرام" class="agency_tooltip"><img src="'.$img_url.'tl.png"  /></a></li>
            <li class="agency_social"><a target="_blank" href="'.$agency["a_facebook"].'" titles="فیسبوک" class="agency_tooltip"><img src="'.$img_url.'fb.png" /></a></li>
            <li class="agency_social"><a target="_blank" href="'.$agency["a_instagram"].'" titles="اینستاگرام" class="agency_tooltip"><img src="'.$img_url.'in.png" /></a></li>
            <li class="agency_social"><a target="_blank" href="'.$agency["a_google"].'" titles="گوگل پلاس" class="agency_tooltip"><img src="'.$img_url.'gp.png" /></a></li>
             <li class="agency_social"><a target="_blank" href="'.$agency["a_aparat"].'" titles="آپارات" class="agency_tooltip"><img src="'.$img_url.'ap.png" /></a></li>
            </ul>
            </li></ul>';
             }//end agency_social
             echo'</div></div></div>';
            echo $res;
             $i=$i+1;
             $ali='';
             }//end foreach
           }
           else{
            echo'<span class="no-agency">هیچ موردی با جست و جوی شما مطابقت نداشت </span>';
        }
            die();
        }//end  search_agency func



        public static function list_agency()
        {
           global $wpdb;
           $id=$_POST['id'];
           $ostani=$_POST['ostani'];
           $type=$_POST['type'];
           $table_name=$wpdb->prefix."agency_list";
           if($type=="all" && $type!=""){
           $agency=$wpdb->get_results("SELECT * FROM $table_name WHERE a_city='$id' AND a_state=$ostani",ARRAY_A);
           }
           else
           {
            $type=rtrim($type,",");
            $agency=$wpdb->get_results("SELECT * FROM $table_name WHERE a_city='$id' AND a_state=$ostani AND a_type IN ($type)",ARRAY_A);
           }
           $type=$wpdb->get_results('SELECT * FROM '.$wpdb->prefix."agency_type".' ORDER BY id ASC',ARRAY_A);
            $arr=array();
            if(sizeof($type)!=0)
            {
             foreach($type as $type)
            {
            $arr[$type['id']]=$type['name'];
            }
            }
           if(get_option('agency_brands')=='yes') {
           $brands=$wpdb->get_results('SELECT * FROM '.$wpdb->prefix."agency_brands".' ORDER BY id ASC',ARRAY_A);
           }
         if(sizeof($agency)!=0)
           {
             $i=0;
             foreach($agency as $agency)
             {
            if(get_option('agency_brands')=='yes') {
            $ar_brand=explode(",",$agency['a_brands']);
            foreach($brands as $brandi)
             {
              if(in_array($brandi['id'],$ar_brand))
              {
             $ali.='<li>'.$brandi['name'].'</li>';
              }
              }//end foreach
              }//end if  agency_brands
              if($i%2==0){
              $res='<div class="agency_right">';
              }
              else{
                $res='<div class="agency_left">';
              }
              $res.='<div class="agency_self">';
         $res.='<ul class="agency_ul">
              <li class="agency_lable">نام شرکت:</li>
              <li class="agency_daron">'.$agency["a_name"].'</li>
              </ul>';
           if(get_option('agency_type')=='yes')
         {
           $res.='<ul class="agency_ul">
              <li class="agency_lable">نوع نمایندگی:</li>
              <li class="agency_daron">'.$arr[$agency["a_type"]].'</li>
              </ul>';
         }
            if(get_option('agency_fname')=='yes')
         {
           $res.='<ul class="agency_ul">
              <li class="agency_lable">نام نماینده:</li>
              <li class="agency_daron">'.$agency["a_fname"].'</li>
              </ul>';
         }
               $res.='<ul class="agency_ul">
              <li class="agency_lable" id="lb_more"><i id="agencymob-'.$agency["id"].'">+</i><a href="javascript:void(0)" onclick="agency_more('.$agency["id"].')" id="agencymod-'.$agency["id"].'">اطلاعات بیشتر</a></li>
              <li class="agency_daron"></li>
              </ul>';
         $res.='<div class="agency_more" id="agencymore-'.$agency["id"].'">';
          if(get_option('agency_phone')=='yes')
         {
         $res.='<ul class="agency_ul">
              <li class="agency_lable">شماره تلفن:</li>
              <li class="agency_daron">'.$agency["a_phone"].'</li>
              </ul>';
         }
         if(get_option('agency_fax')=='yes')
         {
            $res.='<ul class="agency_ul">
              <li class="agency_lable">شماره فکس:</li>
              <li class="agency_daron">'.$agency["a_fax"].'</li>
              </ul>';
         }
           if(get_option('agency_mobile')=='yes')
           {
            $res.='<ul class="agency_ul">
              <li class="agency_lable">تلفن همراه:</li>
              <li class="agency_daron">'.$agency["a_mobile"].'</li>
              </ul>';
           }
            if(get_option('agency_mail')=='yes')
           {
            $res.='<ul class="agency_ul">
             <li class="agency_lable">ایمیل :</li>
             <li class="agency_daron">'.$agency["a_email"].'</li>
             </ul>';
          }
         if(get_option('agency_site')=='yes')
         {
         $mystring='https://';
         if($agency["a_site"]!="")
         {
         $findme=$agency["a_site"] ;
         $pos=strpos($mystring, $findme);
           if($pos!== false)
           {
           $res.='<ul class="agency_ul">
             <li class="agency_lable">وبسایت :</li>
             <li class="agency_daron"><a class="site" target="_blank" href="https://'.$agency["a_site"].'">'.$agency["a_site"].'</a></li>
             </ul>';
            }
           else
           {

          $res.='<ul class="agency_ul">
             <li class="agency_lable">وبسایت:</li>
             <li class="agency_daron"><a class="site" target="_blank" href="http://'.$agency["a_site"].'">'.$agency["a_site"].'</a></li>
             </ul>';
           }//end else
        }//end if a_site
        else
         {
           $res.='<ul class="agency_ul">
             <li class="agency_lable">وبسایت:</li>
             <li class="agency_daron"></li>
              </ul>';
         }

        }// end get_option site
            $img_url=plugins_url('agency/images/');
             $res.='<ul class="agency_ul">
             <li class="agency_lable">آدرس:</li>
             <li class="agency_daron">'.$agency["a_address"].'</li>
             </ul>';
             if(get_option('agency_postcode')=='yes') {
              $res.='<ul class="agency_ul">
             <li class="agency_lable">کد پستی:</li>
             <li class="agency_daron">'.$agency["a_postcode"].'</li>
             </ul>';
             }
             if(get_option('agency_brands')=='yes') {
             $res.='<ul class="agency_ul">
             <li class="agency_lable">حوزه های فعالیت:</li>
             <li class="agency_daron"><ul class="agency_brands">'.$ali.'</ul></li>
             </ul>';
             }
              if(get_option('agency_social')=='yes')
         {
              $res.='<ul class="agency_ul">

         <li class="agency_daron_social">
         <ul class="agency_social_list">
            <li class="agency_social"><a  target="_blank" href="'.$agency["a_telegram"].'" titles="تلگرام" class="agency_tooltip"><img src="'.$img_url.'tl.png"  /></a></li>
            <li class="agency_social"><a target="_blank" href="'.$agency["a_facebook"].'" titles="فیسبوک" class="agency_tooltip"><img src="'.$img_url.'fb.png" /></a></li>
            <li class="agency_social"><a target="_blank" href="'.$agency["a_instagram"].'" titles="اینستاگرام" class="agency_tooltip"><img src="'.$img_url.'in.png" /></a></li>
            <li class="agency_social"><a target="_blank" href="'.$agency["a_google"].'" titles="گوگل پلاس" class="agency_tooltip"><img src="'.$img_url.'gp.png" /></a></li>
             <li class="agency_social"><a target="_blank" href="'.$agency["a_aparat"].'" titles="آپارات" class="agency_tooltip"><img src="'.$img_url.'ap.png" /></a></li>
            </ul>
            </li></ul>';
             }//end agency_social
             echo'</div></div></div>';
            echo $res;
             $i=$i+1;
             $ali='';
             }//end foreach
           }
           else{
            echo'<span class="no-agency">'.get_option("agency_message_pno").'</span>';
        }
            die();
        }//end  list_agency func





     public static function city()
      {
        global $wpdb;
        $id=$_POST['id'];
        $type=$_POST['type'];
        $table_name=$wpdb->prefix."agency_list";
        if($type=="all" && $type!=""){
        $agency=$wpdb->get_results('SELECT DISTINCT a_city FROM '.$table_name.' WHERE a_state='.$id.' ORDER BY a_city',ARRAY_A);
        }
        else{
         $type=rtrim($type,",");
         $agency=$wpdb->get_results('SELECT DISTINCT a_city FROM '.$table_name.' WHERE a_state='.$id.' AND a_type IN ('.$type.')  ORDER BY a_city',ARRAY_A);
        }
         if(sizeof($agency)!=0)
         {
          echo'<select name="city" id="a_city">';
          echo"<option value='all'>تمام شهرها</option>";
            foreach($agency as $agency)
           {
            ?>
             <option value="<?php echo $agency['a_city']; ?>"><?php echo $agency['a_city']; ?></option>
              <?php
           }//end foreach
           echo"</select>";
         }//end if

        die();
       }//end list_agency

   public static function upgrade_agency()
     {
        global $wpdb;
       $tables_name=$wpdb->prefix."agency_brands";
      if($wpdb->get_var("show tables like '$tables_name'")!=$tables_name)
      {
        $sql="CREATE TABLE ".$tables_name." (
             `id` int NOT NULL AUTO_INCREMENT,
             `name` varchar(255) COLLATE utf8_persian_ci   NOT NULL,
             `img_brands` varchar(255)  NOT NULL,
             PRIMARY KEY (`id`)
             )";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta($sql);

      }//end if
       $table_name=$wpdb->prefix."agency_type";
      if($wpdb->get_var("show tables like '$table_name'")!=$table_name)
     {
     $sql="CREATE TABLE ".$table_name." (
    `id` int NOT NULL AUTO_INCREMENT,
    `name` varchar(100) COLLATE utf8_persian_ci   NOT NULL,
     PRIMARY KEY (`id`)
    )";

     require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
     dbDelta( $sql );

    }//end if

       $table_names=$wpdb->prefix."agency_list";
       $sql1="ALTER TABLE ".$table_names." ADD `a_brands` varchar(255) NULL,
       ADD  `a_telegram` varchar(255) NULL,
       ADD  `a_instagram` varchar(255) NULL,
       ADD  `a_facebook` varchar(255) NULL,
       ADD `a_google` varchar(255) NULL,
       ADD `a_aparat` varchar(255) NULL,
       ADD `a_type` varchar(8) NULL,
       ADD `a_postcode` varchar(10) NULL";
     // $res=$wpdb->query($sql);
     $rwe=$wpdb->query("SHOW COLUMNS FROM  $table_names LIKE 'a_brands'");
     if(!$rwe){
     $result=$wpdb->query("ALTER TABLE ".$table_names." ADD a_brands varchar(255) NULL");
    }
    $rwe=$wpdb->query("SHOW COLUMNS FROM  $table_names LIKE 'a_telegram'");
     if(!$rwe){
     $result=$wpdb->query("ALTER TABLE ".$table_names." ADD  a_telegram varchar(255) NULL");
    }
    $rwe=$wpdb->query("SHOW COLUMNS FROM  $table_names LIKE 'a_instagram'");
     if(!$rwe){
     $result=$wpdb->query("ALTER TABLE ".$table_names." ADD  a_instagram varchar(255) NULL");
    }
     $rwe=$wpdb->query("SHOW COLUMNS FROM  $table_names LIKE 'a_facebook'");
     if(!$rwe){
     $result =$wpdb->query("ALTER TABLE ".$table_names." ADD  a_facebook varchar(255) NULL");
    }
     $rwe=$wpdb->query("SHOW COLUMNS FROM  $table_names LIKE 'a_google'");
     if(!$rwe){
     $result=$wpdb->query("ALTER TABLE ".$table_names." ADD  a_google varchar(255) NULL");
    }
     $rwe=$wpdb->query("SHOW COLUMNS FROM  $table_names LIKE 'a_aparat'");
     if(!$rwe){
     $result=$wpdb->query("ALTER TABLE ".$table_names." ADD  a_aparat varchar(255) NULL");
    }
    $rwe=$wpdb->query("SHOW COLUMNS FROM  $table_names LIKE 'a_type'");
     if(!$rwe){
     $result=$wpdb->query("ALTER TABLE ".$table_names." ADD a_type varchar(255) NULL");
    }
   $rwe=$wpdb->query("SHOW COLUMNS FROM  $table_names LIKE 'a_postcode'");
     if(!$rwe){
     $result=$wpdb->query("ALTER TABLE ".$table_names." ADD  a_postcode varchar(255) NULL");
    }
    $num_row=$wpdb->query("SHOW COLUMNS FROM  $table_names");
    if($num_row==20)
    {
    echo 1;
    }
    else{
     echo 0;
    }
    die();


    }//end upgrade_agency func


 public static function install(){
 add_option('agency_fname','no');
 add_option('agency_mobile','no');
 add_option('agency_phone','yes');
 add_option('agency_fax','yes');
 add_option('agency_mail','yes');
 add_option('agency_site','yes');
 add_option('agency_count','10');
 add_option('agency_social','yes');
 add_option('agency_brands','yes');
 add_option('agency_help_color','yes');
 add_option('agency_type','yes');
 add_option('agency_postcode','yes');
 add_option('agency_message_pno','در این استان نمایندگی یا عاملیت فروش وجود ندارد');
 add_option('agency_list_color','003292');
 add_option('agency_list_hcolor','c33a2c');
 add_option('agency_city_color','DA1F26');
 add_option('agency_city_hcolor','003292');
 add_option('agency_map_pfound_color','4ECC81');
 add_option('agency_map_pfound_hcolor','c33a2c');
 add_option('agency_map_pno_color','7b7a79');
 add_option('agency_map_pno_hcolor','c33a2c');



 global $wpdb;
 $table_name=$wpdb->prefix."agency_state";
 if($wpdb->get_var("show tables like '$table_name'")!=$table_name) {
 $sql="CREATE TABLE ".$table_name." (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_persian_ci   NOT NULL,
  PRIMARY KEY (`id`)
)";
$sql1="INSERT INTO ".$table_name." (`id`,`name`) VALUES
(1, 'آذربایجانشرقی'),
(2, 'آذربایجان غربی'),
(3, 'اردبیل'),
(4, 'اصفهان'),
(5, 'البرز'),
(6, 'ایلام'),
(7, 'بوشهر'),
(8, 'تهران'),
(9, 'چهارمحال بختیاری'),
(10, 'خراسان جنوبی'),
(11, 'خراسان رضوی'),
(12, 'خراسان شمالی'),
(13, 'خوزستان'),
(14, 'زنجان'),
(15, 'سمنان'),
(16, 'سیستان و بلوچستان'),
(17, 'فارس'),
(18, 'قزوین'),
(19, 'قم'),
(20, 'کردستان'),
(21, 'کرمان'),
(22, 'کرمانشاه'),
(23, 'کهگیلویه و بویراحمد'),
(24, 'گلستان'),
(25, 'گیلان'),
(26, 'لرستان'),
(27, 'مازندران'),
(28, 'مرکزی'),
(29, 'هرمزگان'),
(30, 'همدان'),
(31, 'یزد'),
(32, 'ابوموسی'),
(33, 'قشم'),
(34, 'فرور بزرگ'),
(35, 'فرورکوچک'),
(36, 'هندورابی'),
(37, 'هنگام'),
(38, 'هرمز'),
(39, 'خارک'),
(40, 'کیش'),
(41, 'لارک'),
(42, 'لاوان'),
(43, 'سیری'),
(44, 'تنب بزرگ'),
(45, 'تنب کوچک');";

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );
dbDelta( $sql1 );

}//end if
 $table_name=$wpdb->prefix."agency_brands";
 if($wpdb->get_var("show tables like '$table_name'")!=$table_name)
 {
 $sql="CREATE TABLE ".$table_name." (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_persian_ci   NOT NULL,
  `img_brands` varchar(255)  NOT NULL,
   PRIMARY KEY (`id`)
)";

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );

}//end if

 $table_name=$wpdb->prefix."agency_type";
 if($wpdb->get_var("show tables like '$table_name'")!=$table_name)
 {
 $sql="CREATE TABLE ".$table_name." (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_persian_ci   NOT NULL,
   PRIMARY KEY (`id`)
)";

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );

}//end if


$table_name=$wpdb->prefix."agency_list";
if($wpdb->get_var("show tables like '$table_name'")!=$table_name) {
 $sql_list="CREATE TABLE ".$table_name." (
  `id` int NOT NULL AUTO_INCREMENT,
  `a_name` varchar(255)   NOT NULL,
  `a_fname` varchar(255)  NULL,
  `a_state` varchar(6)   NOT NULL,
  `a_city` varchar(128)   NOT NULL,
  `a_phone` varchar(20)  NULL,
  `a_fax` varchar(20) NULL,
  `a_mobile` varchar(16) NULL,
  `a_site` varchar(128) NULL,
  `a_email` varchar(128) NULL,
  `a_address` varchar(255) NULL,
  `a_date` int(10) NULL,
  `a_brands` varchar(255) NULL,
  `a_telegram` varchar(255) NULL,
  `a_instagram` varchar(255) NULL,
  `a_facebook` varchar(255) NULL,
  `a_google` varchar(255) NULL,
  `a_aparat` varchar(255) NULL,
  `a_type` varchar(8) NULL,
  `a_postcode` varchar(10) NULL,
  PRIMARY KEY (`id`)
) CHARSET=utf8 COLLATE=utf8_persian_ci";
require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta($sql_list);
}//if list

}//end install

public static function agency_unistall(){
$table_name[0]=$wpdb->prefix."agency_state";
$table_name[1]=$wpdb->prefix."agency_brands";
$table_name[2]=$wpdb->prefix."agency_list";
foreach($table_name as $x=>$x_table)
{
 //$sql = "DROP TABLE IF EXISTS $table_name";
 //$wpdb->query($sql);
 //delete_option('e34s_time_card_version');
 $wpdb->query( "DROP TABLE IF EXISTS ".$x_table);
}//end table


}//end  agency_unistall
public static function admin_init(){
 register_setting('agency_options','agency_fname');
 register_setting('agency_options','agency_mobile');
 register_setting('agency_options','agency_phone');
 register_setting('agency_options','agency_fax');
 register_setting('agency_options','agency_mail');
 register_setting('agency_options','agency_site');
 register_setting('agency_options','agency_count');
 register_setting('agency_options','agency_social');
 register_setting('agency_options','agency_brands');
 register_setting('agency_options','agency_type');
 register_setting('agency_options','agency_postcode');
 register_setting('agency_options','agency_help_color');
 register_setting('agency_options','agency_message_pno');
 register_setting('agency_css_options','agency_list_color');
 register_setting('agency_css_options','agency_list_hcolor');
 register_setting('agency_css_options','agency_city_color');
 register_setting('agency_css_options','agency_city_hcolor');
 register_setting('agency_css_options','agency_map_pfound_color');
 register_setting('agency_css_options','agency_map_pfound_hcolor');
 register_setting('agency_css_options','agency_map_pno_color');
 register_setting('agency_css_options','agency_map_pno_hcolor');
 } //end admin_init func

public static function add_agency()
 {
   require_once AGENCY_PLUGIN.'add_agency.php';

 }//end add_agency

 public static function admin_enqueue_scripts()
  {

      wp_enqueue_style('admin_agency',plugins_url('agency/css/admin_agency.css'));
      wp_enqueue_script('jscolor',plugins_url('agency/js/jscolor.min.js'));
      wp_enqueue_script('agency_ajax_2',plugins_url('agency/js/agency_ajax.js'),array('jquery'),'2');
      wp_localize_script('agency_ajax_2','myAjax',array('ajaxurl'=>admin_url('admin-ajax.php')));


 }//end admin

    public static function plugin_file()
     {

     wp_enqueue_style('agency_style',plugins_url('agency/css/agency_style.css'));
     wp_enqueue_script('fr_agency_2',plugins_url('agency/js/fr_agency.js'),array('jquery'),'2');
     wp_localize_script('fr_agency_2','myAjax',array('ajaxurl'=>admin_url('admin-ajax.php')));
     agency::build_stylesheet_custom();
     ?>
     <?php


     }//end state func


   public static function build_stylesheet_custom() {

  ?>
 <style type="text/css">
 #map_agency .agency_list li ul li a {
    background: #<?php echo get_option('agency_list_color');?>!important;
  }
 #map_agency .agency_list li ul li a:hover{
    background:#<?php echo get_option('agency_list_hcolor');?>!important;
}
#map_agency .city_agency{
    color #<?php echo get_option('agency_city_color');?>!important;
  }
 #map_agency  a.city_agency:hover{
    color:#<?php echo get_option('agency_city_hcolor');?>!important;
}

 #map_agency .map_agency .province .agency_pno{
    fill:#<?php echo get_option('agency_map_pno_color');?>!important;
}
 #map_agency .map_agency .province .agency_pno:hover{
    fill:#<?php echo get_option('agency_map_pno_hcolor');?>!important;
}

#map_agency .map_agency .province .agency_pfound{
    fill:#<?php echo get_option('agency_map_pfound_color');?>!important;
}
 #map_agency .map_agency .province .agency_pfound:hover{
     fill:#<?php echo get_option('agency_map_pfound_hcolor');?>!important;
}

 </style>
    <?php
    }

  public static function wp_agency_link($atts)
   {

         ob_start();
         require_once AGENCY_PLUGIN.'agency_link.php';
         $list_arg=shortcode_atts(array('type'=>'all'),$atts);
         wp_agency_show($list_arg['type']);
         return ob_get_clean();



    } //end wp_product_link function





}//end class

?>